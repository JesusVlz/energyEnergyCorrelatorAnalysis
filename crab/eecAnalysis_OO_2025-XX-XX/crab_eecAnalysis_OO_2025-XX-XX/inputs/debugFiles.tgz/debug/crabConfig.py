from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = 'eecAnalysis_OO_2025-XX-XX'
config.General.workArea = 'eecAnalysis_OO_2025-XX-XX'
config.section_('JobType')
config.JobType.maxJobRuntimeMin = 120
config.JobType.inputFiles = ['FrameworkJobReport.xml', 'eecOO.tar.gz', 'cardEECOO.input']
config.JobType.psetName = 'PSet.py'
config.JobType.pluginName = 'Analysis'
config.JobType.scriptArgs = ['card=cardEECOO.input', 'output=eecAnalysis_OO_2025-XX-XX.root', 'location=1', 'mixinglist=none']
config.JobType.outputFiles = ['eecAnalysis_OO_2025-XX-XX.root']
config.JobType.maxMemoryMB = 600
config.JobType.scriptExe = 'compileAndRun.sh'
config.section_('Data')
config.Data.totalUnits = 1
config.Data.outputPrimaryDataset = 'eecOOHistograms'
config.Data.outLFNDirBase = '/store/group/phys_heavyions/jvelazqu/energycorr/OO2025/eecAnalysis_OO_2025-XX-XX'
config.Data.publication = False
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.userInputFiles = ['/store/group/phys_heavyions/jvelazqu/OO2025_dataset_MinimumBias_filtered/IonPhysics0/OO_MinimumBias_filtered_IonPhysics0/260908_000643/0000/L1_object_data_100.root\n']
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.Site.whitelist = ['T2_CH_CERN']
config.section_('Debug')
config.Debug.extraJDL = ['+CMS_ALLOW_OVERFLOW=False']
