// Do NOT change. Changes will be lost next time file is generated

#define R__DICTIONARY_FILENAME nanoDict
#define R__NO_DEPRECATION

/*******************************************************************/
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#define G__DICTIONARY
#include "ROOT/RConfig.hxx"
#include "TClass.h"
#include "TDictAttributeMap.h"
#include "TInterpreter.h"
#include "TROOT.h"
#include "TBuffer.h"
#include "TMemberInspector.h"
#include "TInterpreter.h"
#include "TVirtualMutex.h"
#include "TError.h"

#ifndef G__ROOT
#define G__ROOT
#endif

#include "RtypesImp.h"
#include "TIsAProxy.h"
#include "TFileMergeInfo.h"
#include <algorithm>
#include "TCollectionProxyInfo.h"
/*******************************************************************/

#include "TDataMember.h"

// Header files passed as explicit arguments
#include "SplitCanvas.h"

// Header files passed via #pragma extra_include

// The generated code does not explicitly qualify STL entities
namespace std {} using namespace std;

namespace ROOT {
   static TClass *SplitCanvas_Dictionary();
   static void SplitCanvas_TClassManip(TClass*);
   static void *new_SplitCanvas(void *p = nullptr);
   static void *newArray_SplitCanvas(Long_t size, void *p);
   static void delete_SplitCanvas(void *p);
   static void deleteArray_SplitCanvas(void *p);
   static void destruct_SplitCanvas(void *p);

   // Function generating the singleton type initializer
   static TGenericClassInfo *GenerateInitInstanceLocal(const ::SplitCanvas*)
   {
      ::SplitCanvas *ptr = nullptr;
      static ::TVirtualIsAProxy* isa_proxy = new ::TIsAProxy(typeid(::SplitCanvas));
      static ::ROOT::TGenericClassInfo 
         instance("SplitCanvas", "SplitCanvas.h", 14,
                  typeid(::SplitCanvas), ::ROOT::Internal::DefineBehavior(ptr, ptr),
                  &SplitCanvas_Dictionary, isa_proxy, 0,
                  sizeof(::SplitCanvas) );
      instance.SetNew(&new_SplitCanvas);
      instance.SetNewArray(&newArray_SplitCanvas);
      instance.SetDelete(&delete_SplitCanvas);
      instance.SetDeleteArray(&deleteArray_SplitCanvas);
      instance.SetDestructor(&destruct_SplitCanvas);
      return &instance;
   }
   TGenericClassInfo *GenerateInitInstance(const ::SplitCanvas*)
   {
      return GenerateInitInstanceLocal(static_cast<::SplitCanvas*>(nullptr));
   }
   // Static variable to force the class initialization
   static ::ROOT::TGenericClassInfo *_R__UNIQUE_DICT_(Init) = GenerateInitInstanceLocal(static_cast<const ::SplitCanvas*>(nullptr)); R__UseDummy(_R__UNIQUE_DICT_(Init));

   // Dictionary for non-ClassDef classes
   static TClass *SplitCanvas_Dictionary() {
      TClass* theClass =::ROOT::GenerateInitInstanceLocal(static_cast<const ::SplitCanvas*>(nullptr))->GetClass();
      SplitCanvas_TClassManip(theClass);
   return theClass;
   }

   static void SplitCanvas_TClassManip(TClass* ){
   }

} // end of namespace ROOT

namespace ROOT {
   // Wrappers around operator new
   static void *new_SplitCanvas(void *p) {
      return  p ? new(p) ::SplitCanvas : new ::SplitCanvas;
   }
   static void *newArray_SplitCanvas(Long_t nElements, void *p) {
      return p ? new(p) ::SplitCanvas[nElements] : new ::SplitCanvas[nElements];
   }
   // Wrapper around operator delete
   static void delete_SplitCanvas(void *p) {
      delete (static_cast<::SplitCanvas*>(p));
   }
   static void deleteArray_SplitCanvas(void *p) {
      delete [] (static_cast<::SplitCanvas*>(p));
   }
   static void destruct_SplitCanvas(void *p) {
      typedef ::SplitCanvas current_t;
      (static_cast<current_t*>(p))->~current_t();
   }
} // end of namespace ROOT for class ::SplitCanvas

namespace {
  void TriggerDictionaryInitialization_nanoDict_Impl() {
    static const char* headers[] = {
"SplitCanvas.h",
nullptr
    };
    static const char* includePaths[] = {
"/cvmfs/cms.cern.ch/el9_amd64_gcc12/lcg/root/6.32.13-3ea6c37f14e3f39c0c3ce338c09aec10/include/",
"/afs/cern.ch/user/j/jvelazqu/EECAnalysis/CMSSW_15_0_9_patch4/src/energyEnergyCorrelatorAnalysis/plotting/",
nullptr
    };
    static const char* fwdDeclCode = R"DICTFWDDCLS(
#line 1 "nanoDict dictionary forward declarations' payload"
#pragma clang diagnostic ignored "-Wkeyword-compat"
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
extern int __Cling_AutoLoading_Map;
class __attribute__((annotate("$clingAutoload$SplitCanvas.h")))  SplitCanvas;
)DICTFWDDCLS";
    static const char* payloadCode = R"DICTPAYLOAD(
#line 1 "nanoDict dictionary payload"

#ifndef EEC
  #define EEC 1
#endif

#define _BACKWARD_BACKWARD_WARNING_H
// Inline headers
#include "SplitCanvas.h"

#undef  _BACKWARD_BACKWARD_WARNING_H
)DICTPAYLOAD";
    static const char* classesHeaders[] = {
"SplitCanvas", payloadCode, "@",
nullptr
};
    static bool isInitialized = false;
    if (!isInitialized) {
      TROOT::RegisterModule("nanoDict",
        headers, includePaths, payloadCode, fwdDeclCode,
        TriggerDictionaryInitialization_nanoDict_Impl, {}, classesHeaders, /*hasCxxModule*/false);
      isInitialized = true;
    }
  }
  static struct DictInit {
    DictInit() {
      TriggerDictionaryInitialization_nanoDict_Impl();
    }
  } __TheDictionaryInitializer;
}
void TriggerDictionaryInitialization_nanoDict() {
  TriggerDictionaryInitialization_nanoDict_Impl();
}
