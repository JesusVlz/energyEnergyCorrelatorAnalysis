#include "SystematicUncertaintyOrganizer.h" R__LOAD_LIBRARY(plotting/DrawingClasses.so)
#include "EECCard.h"
#include "EECHistogramManager.h"
#include "JDrawer.h"
#include "AlgorithmLibrary.h"

#include <algorithm>

// Function definitions. Implementations after the main macro.
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult[], const int nComparisonGraphs);
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult);
TH1D* findStandardDeviation(TH1D* nominalResult, TH1D* variedResult[], const int nComparisonGraphs);
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend[], TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom);
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom);
void drawIllustratingPlotsMonochrome(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom);

/*
 * Macro for estimating systematic uncertainties for energy-energy correlators in pp collisions
 * This is quite similar to the macro for PbPb, but some sources are treated slightly differently
 * and not all of the sources are the same, so I thought it might be simpler to have different 
 * macros for the different systems in this case.
 *
 * The following sources of systematic uncertainty are estimated:
 *  - Jet energy resolition uncertainty (modifies unfolding response matrix, correlated)
 *  - Jet energy scale uncertainty (modifies unfolding response matrix, correlated)
 *  - Truth reference for jet pT unfolding (modifies unfolding response matrix, correlated)
 *  - Tracking efficiency (uncorrelated)
 *  - Track pair efficiency (uncorrelated)
 *  - Background subtraction (uncorrelated)
 *
 *  The results will be saved to a file and also slides with different contributions can be printed
 *
 * Arguments:
 *  const int weightExponent = Exponents for the energy weight in energy-energy correlators. Currently 1 and 2 are implemented.
 */
void estimateSystematicUncertaintiesForPp(const int weightExponent = 1){

  // First, do a sanity check for the weight exponents. Currently only 1 and 2 are implemented.
  if(weightExponent < 1 || weightExponent > 2){
    cout << "ERROR! The weight exponent you gave has not been implemented!" << endl;
    cout << "Currently only values 1 and 2 are implemented." << endl;
    cout << "Please select one of these values for weight exponent." << endl;
    return;
  }

  TString weightExponentString[2];
  weightExponentString[0] = "nominalEnergyWeight";
  weightExponentString[1] = "energyWeightSquared";
  
  // ==================================================================
  // ============================= Input ==============================
  // ==================================================================

  // Nominal results
  TString nominalResultFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWithNominalSmear_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWithNominalSmear_processed_2024-01-17.root"};
  TFile* nominalResultFile = TFile::Open(nominalResultFileName[weightExponent-1]);
  EECCard* nominalResultCard = new EECCard(nominalResultFile);
  EECHistogramManager* nominalHistogramManager = new EECHistogramManager(nominalResultFile, nominalResultCard);
  
  // Results unfolded with a response matrix smeared with jet energy resolution
  TString jetEnergyResolutionSmearDownFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWithUncertaintySmearDown_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWithUncertaintySmearDown_processed_2024-01-17.root"};
  TString jetEnergyResolutionSmearUpFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWithUncertaintySmearUp_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWithUncertaintySmearUp_processed_2024-01-17.root"};
  TFile* jetEnergyResolutionFile[2];
  jetEnergyResolutionFile[0] = TFile::Open(jetEnergyResolutionSmearDownFileName[weightExponent-1]);
  jetEnergyResolutionFile[1] = TFile::Open(jetEnergyResolutionSmearUpFileName[weightExponent-1]);
  EECCard* jetEnergyResolutionCard[2];
  EECHistogramManager* jetEnergyResolutionHistogramManager[2];
  for(int iJetEnergyResolutionFile = 0; iJetEnergyResolutionFile < 2; iJetEnergyResolutionFile++){
    jetEnergyResolutionCard[iJetEnergyResolutionFile] = new EECCard(jetEnergyResolutionFile[iJetEnergyResolutionFile]);
    jetEnergyResolutionHistogramManager[iJetEnergyResolutionFile] = new EECHistogramManager(jetEnergyResolutionFile[iJetEnergyResolutionFile], jetEnergyResolutionCard[iJetEnergyResolutionFile]);
  }
  
  // Results unfolded with a response matrix smeared with jet energy scale
  TString jetEnergyScaleMinusFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWithMinusJetEnergyScale_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWithMinusJetEnergyScale_processed_2024-01-17.root"};
  TString jetEnergyScalePlusFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWithPlusJetEnergyScale_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWithPlusJetEnergyScale_processed_2024-01-17.root"};
  TFile* jetEnergyScaleFile[2];
  jetEnergyScaleFile[0] = TFile::Open(jetEnergyScaleMinusFileName[weightExponent-1]);
  jetEnergyScaleFile[1] = TFile::Open(jetEnergyScalePlusFileName[weightExponent-1]);
  EECCard* jetEnergyScaleCard[2];
  EECHistogramManager* jetEnergyScaleHistogramManager[2];
  for(int iJetEnergyScaleFile = 0; iJetEnergyScaleFile < 2; iJetEnergyScaleFile++){
    jetEnergyScaleCard[iJetEnergyScaleFile] = new EECCard(jetEnergyScaleFile[iJetEnergyScaleFile]);
    jetEnergyScaleHistogramManager[iJetEnergyScaleFile] = new EECHistogramManager(jetEnergyScaleFile[iJetEnergyScaleFile], jetEnergyScaleCard[iJetEnergyScaleFile]);
  }

  // Results unfolded with a response matrix where jet pT spectrum is weighted to match the data
  TString jetPtPriorFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWithModifiedPrior_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWithModifiedPrior_processed_2024-01-17.root"};
  TFile* jetPtPriorFile = TFile::Open(jetPtPriorFileName[weightExponent-1]);
  EECCard* jetPtPriorCard = new EECCard(jetPtPriorFile);
  EECHistogramManager* jetPtPriorHistogramManager = new EECHistogramManager(jetPtPriorFile, jetPtPriorCard);

  // Results unfolded with a different number of iterations compared to nominal results
  TString unfoldingIterationsMinusFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWith3Iterations_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWith3Iterations_processed_2024-01-17.root"};
  TString unfoldingIterationsPlusFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWith5Iterations_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWith5Iterations_processed_2024-01-17.root"};
  TFile* unfoldingIterationsFile[2];
  unfoldingIterationsFile[0] = TFile::Open(unfoldingIterationsMinusFileName[weightExponent-1]);
  unfoldingIterationsFile[1] = TFile::Open(unfoldingIterationsPlusFileName[weightExponent-1]);
  EECCard* unfoldingIterationsCard[2];
  EECHistogramManager* unfoldingIterationsHistogramManager[2];
  for(int iUnfoldingIterationsFile = 0; iUnfoldingIterationsFile < 2; iUnfoldingIterationsFile++){
    unfoldingIterationsCard[iUnfoldingIterationsFile] = new EECCard(unfoldingIterationsFile[iUnfoldingIterationsFile]);
    unfoldingIterationsHistogramManager[iUnfoldingIterationsFile] = new EECHistogramManager(unfoldingIterationsFile[iUnfoldingIterationsFile], unfoldingIterationsCard[iUnfoldingIterationsFile]);
  }

  // Results where background scaling factor is determined from peripheral Pythia+Hydjet instead of not subtracting background
  TString backgroundSubtractionFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_unfoldingWithNominalSmear_backgroundSubtractionSystematics_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_jet60or80triggers_unfoldingWithNominalSmear_backgroundSubtractionSystematics_processed_2024-01-17.root"};
  TFile* backgroundSubtractionFile = TFile::Open(backgroundSubtractionFileName[weightExponent-1]);
  EECCard* backgroundSubtractionCard = new EECCard(backgroundSubtractionFile);
  EECHistogramManager* backgroundSubtractionHistogramManager = new EECHistogramManager(backgroundSubtractionFile, backgroundSubtractionCard);

  // Result with different track selections
  TString looseTrackSelectionFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_looseTrackCuts_jet60or80triggers_unfoldingWithNominalSmear_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_looseTrackCuts_jet60or80triggers_unfoldingWithNominalSmear_processed_2024-01-18.root"};
  TString tightTrackSelectionFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_tightTrackCuts_jet60or80triggers_unfoldingWithNominalSmear_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_tightTrackCuts_jet60or80triggers_unfoldingWithNominalSmear_processed_2024-01-18.root"};
  TFile* trackSelectionFile[2];
  trackSelectionFile[0] = TFile::Open(looseTrackSelectionFileName[weightExponent-1]);
  trackSelectionFile[1] = TFile::Open(tightTrackSelectionFileName[weightExponent-1]);
  EECCard* trackSelectionCard[2];
  EECHistogramManager* trackSelectionHistogramManager[2];
  for(int iTrackSelectionFile = 0; iTrackSelectionFile < 2; iTrackSelectionFile++){
    trackSelectionCard[iTrackSelectionFile] = new EECCard(trackSelectionFile[iTrackSelectionFile]);
    trackSelectionHistogramManager[iTrackSelectionFile] = new EECHistogramManager(trackSelectionFile[iTrackSelectionFile], trackSelectionCard[iTrackSelectionFile]);
  }


  // Results with varied single and pair track efficiency
  TString trackEfficiencyFileName[2] = {"data/ppData_pfJets_wtaAxis_nominalEnergyWeight_optimizedUnfoldingBins_trackSystematics_jet60or80triggers_processed_2024-04-18.root", "data/ppData_pfJets_wtaAxis_energyWeightSquared_optimizedUnfoldingBins_trackSystematics_jet60or80triggers_unfoldingWithNominalSmear_processed_2024-01-17.root"};
  TFile* trackEfficiencyFile = TFile::Open(trackEfficiencyFileName[weightExponent-1]);
  EECCard* trackEfficiencyCard = new EECCard(trackEfficiencyFile);
  EECHistogramManager* trackEfficiencyHistogramManager = new EECHistogramManager(trackEfficiencyFile, trackEfficiencyCard);

  // Results where the unfolding has been done with randomized response matrices to evaluate MC statistics uncertainty
  const int nMCStatisticsRandomizations = 50;
  TString mcStatisticsFileName[nMCStatisticsRandomizations];
  for(int iVariation = 0; iVariation < nMCStatisticsRandomizations; iVariation++){
    mcStatisticsFileName[iVariation] = Form("data/mcStatisticsRandomization/ppData_pfJets_wtaAxis_%s_optimizedUnfoldingBins_mcStatisticsUncertaintyRandom%d_jet60or80triggers_processed_2025-04-21.root", weightExponentString[weightExponent-1].Data(), iVariation+1);
  }
  TFile* mcStatisticsFile[nMCStatisticsRandomizations];
  EECCard* mcStatisticsCard[nMCStatisticsRandomizations];
  EECHistogramManager* mcStatisticsHistogramManager[nMCStatisticsRandomizations];
  for(int iMonteCarloStatisticsFile = 0; iMonteCarloStatisticsFile < nMCStatisticsRandomizations; iMonteCarloStatisticsFile++){
    mcStatisticsFile[iMonteCarloStatisticsFile] = TFile::Open(mcStatisticsFileName[iMonteCarloStatisticsFile]);
    mcStatisticsCard[iMonteCarloStatisticsFile] = new EECCard(mcStatisticsFile[iMonteCarloStatisticsFile]);
    mcStatisticsHistogramManager[iMonteCarloStatisticsFile] = new EECHistogramManager(mcStatisticsFile[iMonteCarloStatisticsFile], mcStatisticsCard[iMonteCarloStatisticsFile]);
  }

  // File containing relative uncertainties resulting from Monte Carlo non-closure
  TString monteCarloNonClosureFileName[2] = {"systematicUncertainties/monteCarloNonClosureRelative_pp_nominalEnergyWeight_2024-01-29.root", "systematicUncertainties/monteCarloNonClosureRelative_pp_energyWeightSquared_2024-01-29.root"};
  TFile* monteCarloNonClosureFile = TFile::Open(monteCarloNonClosureFileName[weightExponent-1]);
  EECCard* monteCarloNonClosureCard = new EECCard(monteCarloNonClosureFile);
  
  // ==================================================================
  // ========================= Configuration ==========================
  // ==================================================================
  
  // Find the number of bins from the card
  const int nJetPtBinsEEC = nominalResultCard->GetNJetPtBinsEEC();
  const int nTrackPtBinsEEC = nominalResultCard->GetNTrackPtBinsEEC();
  
  // Estimate the uncertainties for all bins that have been unfolded
  int firstStudiedJetPtBinEEC = nominalResultCard->GetFirstUnfoldedJetPtBin();
  int lastStudiedJetPtBinEEC = nominalResultCard->GetLastUnfoldedJetPtBin();
  
  int firstStudiedTrackPtBinEEC = nominalResultCard->GetFirstUnfoldedTrackPtBin();
  int lastStudiedTrackPtBinEEC = nominalResultCard->GetLastUnfoldedTrackPtBin();

  // Only draw example plots from selected subset of bins
  vector<int> drawnJetPtBins = {5,6,7,8};
  vector<int> drawnTrackPtBins = {1,3,5};
  
  const bool printUncertainties = false;
  
  std::pair<double, double> analysisDeltaR = std::make_pair(0.008, 0.39); // DeltaR span in which the analysis is done
  std::pair<double, double> ratioZoom = std::make_pair(0.9, 1.1);         // Y-axis zoom for rations
  bool setAutomaticRatioZoom = true;                                      // If true, use predefined ratio zooms for systematic uncertainties

  // Transformer used for Monte Carlo non-closure uncertainty
  AlgorithmLibrary* optimusPrimeTheTransformer = new AlgorithmLibrary();
  TString today = optimusPrimeTheTransformer->GetToday();
  
  TString nameAdder[] = {"_nominalEnergyWeight","_energyWeightSquared"}; 
  TString outputFileName = Form("systematicUncertainties/systematicUncertainties_pp%s_includeMCstats_%s.root", nameAdder[weightExponent-1].Data(), today.Data());
  //TString outputFileName = Form("systematicUncertainties/systematicUncertaintiesForPp%s_justASillyDummyFile_%s.root", nameAdder[weightExponent-1].Data(), today.Data());
  
  // Option to skip evaluating some of the sources defined in SystematicUncertaintyOrganizer or not plotting examples of some
  // SystematicUncertaintyOrganizer::kJetEnergyResolution
  // SystematicUncertaintyOrganizer::kJetEnergyScale
  // SystematicUncertaintyOrganizer::kUnfoldingTruth
  // SystematicUncertaintyOrganizer::kUnfoldingIterations
  // SystematicUncertaintyOrganizer::kBackgroundSubtraction
  // SystematicUncertaintyOrganizer::kTrackSelection
  // SystematicUncertaintyOrganizer::kSingleTrackEfficiency
  // SystematicUncertaintyOrganizer::kTrackPairEfficiency
  // SystematicUncertaintyOrganizer::kMonteCarloStatistics
  // SystematicUncertaintyOrganizer::kMonteCarloNonClosure
  bool skipUncertaintySource[SystematicUncertaintyOrganizer::knUncertaintySources];
  bool plotExample[SystematicUncertaintyOrganizer::knUncertaintySources];
  for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
    skipUncertaintySource[iUncertainty] = false;
    plotExample[iUncertainty] = false;
  }
  //plotExample[SystematicUncertaintyOrganizer::kMonteCarloStatistics] = true;
  //skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloStatistics] = false;
  skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloNonClosure] = true;
  
  // ==================================================================
  // ====================== Configuration done ========================
  // ==================================================================
  
  // Systematic uncertainty organizer can easily provide names for all your naming purposes
  SystematicUncertaintyOrganizer* nameGiver = new SystematicUncertaintyOrganizer();
  
  // Histograms for uncertainty estimation
  TH1D* nominalEnergyEnergyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC];
  TH1D* jetEnergyResolutionUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* jetEnergyScaleUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* jetPtPriorUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC];
  TH1D* unfoldingIterationsUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* backgroundSubtractionUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC];
  TH1D* trackSelectionUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* singleTrackEfficiencyUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* trackPairEfficiencyUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* monteCarloStatisticsUncertaintyCorrelators[nJetPtBinsEEC][nTrackPtBinsEEC][nMCStatisticsRandomizations];

  // Histograms to hold the systematic uncertainty results
  TH1D* energyEnergyCorrelatorSystematicUncertainties[nJetPtBinsEEC][nTrackPtBinsEEC][SystematicUncertaintyOrganizer::knUncertaintySources];
  
  // Initialize all the histograms to NULL
  for(int iJetPt = 0; iJetPt < nJetPtBinsEEC; iJetPt++) {
    for(int iTrackPt = 0; iTrackPt < nTrackPtBinsEEC; iTrackPt++) {
      nominalEnergyEnergyCorrelators[iJetPt][iTrackPt] = NULL;
      jetPtPriorUncertaintyCorrelators[iJetPt][iTrackPt] = NULL;
      backgroundSubtractionUncertaintyCorrelators[iJetPt][iTrackPt] = NULL;
      for(int iFile = 0; iFile < 2; iFile++) {
        jetEnergyResolutionUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = NULL;
        jetEnergyScaleUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = NULL;
        unfoldingIterationsUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = NULL;
        trackSelectionUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = NULL;
        singleTrackEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = NULL;
        trackPairEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = NULL;
      }
      for(int iFile = 0; iFile < nMCStatisticsRandomizations; iFile++){
        monteCarloStatisticsUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = NULL;
      }
      for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++) {
        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][iUncertainty] = NULL;
      } // Uncertainty loop
    } // Track pT loop
  } // Jet pT loop

  // Read the histograms from the defined range from the file
  int iTrackPtMatched;
  int iJetPtMatched;
  double epsilon = 0.0001;
  int lowAnalysisBin, highAnalysisBin;

  for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++) {
    for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++) {

      // Read the nominal histograms
      nominalEnergyEnergyCorrelators[iJetPt][iTrackPt] = nominalHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPt, iTrackPt, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

      // Normalize nominal histograms to one in the drawing range
      lowAnalysisBin = nominalEnergyEnergyCorrelators[iJetPt][iTrackPt]->GetXaxis()->FindBin(analysisDeltaR.first + epsilon);
      highAnalysisBin = nominalEnergyEnergyCorrelators[iJetPt][iTrackPt]->GetXaxis()->FindBin(analysisDeltaR.second - epsilon);
      nominalEnergyEnergyCorrelators[iJetPt][iTrackPt]->Scale(1.0 / nominalEnergyEnergyCorrelators[iJetPt][iTrackPt]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

      for(int iFile = 0; iFile < 2; iFile++){

        // Read the jet energy resolution histograms
        iTrackPtMatched = jetEnergyResolutionCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
        iJetPtMatched = jetEnergyResolutionCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
        jetEnergyResolutionUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = jetEnergyResolutionHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

        // Normalize the jet energy resolution histograms to one
        jetEnergyResolutionUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Scale(1.0 / jetEnergyResolutionUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

        // Read the jet energy scale histograms
        iTrackPtMatched = jetEnergyScaleCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
        iJetPtMatched = jetEnergyScaleCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
        jetEnergyScaleUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = jetEnergyScaleHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

        // Normalize the jet energy scale histograms to one
        jetEnergyScaleUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Scale(1.0 / jetEnergyScaleUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

        // Read the track selection histograms
        iTrackPtMatched = trackSelectionCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
        iJetPtMatched = trackSelectionCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
        trackSelectionUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = trackSelectionHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

        // Normalize the track selections histograms to one
        trackSelectionUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Scale(1.0 / trackSelectionUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

        // Read the unfolding number of iteration histograms
        iTrackPtMatched = unfoldingIterationsCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
        iJetPtMatched = unfoldingIterationsCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
        unfoldingIterationsUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = unfoldingIterationsHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

        // Normalize the unfolding number of iteration histograms to one
        unfoldingIterationsUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Scale(1.0 / unfoldingIterationsUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
      }

      // Read the jet pT prior histograms
      iTrackPtMatched = jetPtPriorCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
      iJetPtMatched = jetPtPriorCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
      jetPtPriorUncertaintyCorrelators[iJetPt][iTrackPt] = jetPtPriorHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

      // Normalize the jet energy resolution histograms to one
      jetPtPriorUncertaintyCorrelators[iJetPt][iTrackPt]->Scale(1.0 / jetPtPriorUncertaintyCorrelators[iJetPt][iTrackPt]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

      // Setup the histogram manager for tracking efficiencies
      iTrackPtMatched = trackEfficiencyCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
      iJetPtMatched = trackEfficiencyCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));

      // Read the histograms for single track efficiency
      singleTrackEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][0] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorEfficiencyVariationPlus, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);
      singleTrackEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][1] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorEfficiencyVariationMinus, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

      // Read the histograms for track pair efficiency
      trackPairEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][0] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorPairEfficiencyVariationPlus, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);
      trackPairEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][1] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorPairEfficiencyVariationMinus, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

      for(int iFile = 0; iFile < 2; iFile++) {
        // Normalize the single track efficiency histograms to one
        singleTrackEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Scale(1.0 / singleTrackEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

        // Normalize the track pair efficiency histograms to one
        trackPairEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Scale(1.0 / trackPairEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

      }

      // Read the background subtraction uncertainty histograms
      iTrackPtMatched = backgroundSubtractionCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
      iJetPtMatched = backgroundSubtractionCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
      backgroundSubtractionUncertaintyCorrelators[iJetPt][iTrackPt] = backgroundSubtractionHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

      // Normalize the background subtraction histograms to one
      backgroundSubtractionUncertaintyCorrelators[iJetPt][iTrackPt]->Scale(1.0 / backgroundSubtractionUncertaintyCorrelators[iJetPt][iTrackPt]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

      // Read the Monte Carlo statistics uncertainty histograms
      if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloStatistics]){
        for(int iFile = 0; iFile < nMCStatisticsRandomizations; iFile++){
          iTrackPtMatched = mcStatisticsCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
          iJetPtMatched = mcStatisticsCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
          monteCarloStatisticsUncertaintyCorrelators[iJetPt][iTrackPt][iFile] = mcStatisticsHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, 0, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

          // Normalize the Monte Carlo statistics histograms to one
          monteCarloStatisticsUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Scale(1.0 / monteCarloStatisticsUncertaintyCorrelators[iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
        } // Loop over different response matrix randomizations
      } // Monte Carlo statistics uncertainty histograms

      // Read the relative uncertainty histograms for Monte Carlo non-closure uncertainty
      iTrackPtMatched = monteCarloNonClosureCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
      iJetPtMatched = monteCarloNonClosureCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));

      energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloNonClosure] = (TH1D*) monteCarloNonClosureFile->Get(Form("relativeUncertaintyMonteCarloClosure_pp_J%dT%d", iJetPtMatched, iTrackPtMatched));

    }  // Track pT loop
  }    // Jet pT loop

  // Drawer for illustrative plots
  JDrawer* drawer = new JDrawer();
  drawer->SetDefaultAppearanceSplitCanvas();
  drawer->SetRelativeCanvasSize(1.1,1.1);
  drawer->SetLeftMargin(0.14);
  drawer->SetTopMargin(0.07);
  drawer->SetTitleOffsetY(1.7);
  drawer->SetTitleOffsetX(1.0);
  drawer->SetLogX(true);

  // Legends given to drawns graphs
  TString legendNames[2];
  
  // ================================================= //
  //   Uncertainty coming from jet energy resolution   //
  // ================================================= //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyResolution]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){
        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kJetEnergyResolution] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], jetEnergyResolutionUncertaintyCorrelators[iJetPt][iTrackPt], 2);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kJetEnergyResolution] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)) {
          legendNames[0] = "JER varied response down";
          legendNames[1] = "JER varied response up";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.95,1.05);
          }

          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], jetEnergyResolutionUncertaintyCorrelators[iJetPt][iTrackPt], 2, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kJetEnergyResolution), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }

      } // Track pT loop
    } // Jet pT loop
  } // Jet energy resolution uncertainty

  // ============================================ //
  //   Uncertainty coming from jet energy scale   //
  // ============================================ //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyScale]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kJetEnergyScale] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], jetEnergyScaleUncertaintyCorrelators[iJetPt][iTrackPt], 2);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kJetEnergyScale] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)) {
          legendNames[0] = "JEC varied response down";
          legendNames[1] = "JEC varied response up";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.9,1.1);
          }

          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], jetEnergyScaleUncertaintyCorrelators[iJetPt][iTrackPt], 2, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kJetEnergyScale), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }

      } // Track pT loop
    } // Jet pT loop
  } // Jet energy scale uncertainty

  // ==================================================== //
  //   Uncertainty coming from jet pT prior in unfolding  //
  // ==================================================== //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingTruth]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kUnfoldingTruth] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], jetPtPriorUncertaintyCorrelators[iJetPt][iTrackPt]);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kUnfoldingTruth] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)) {
          legendNames[0] = "Weighted prior";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.95,1.05);
          }

          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], jetPtPriorUncertaintyCorrelators[iJetPt][iTrackPt], iJetPt, iTrackPt, nominalResultCard, legendNames[0], nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kUnfoldingTruth), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }

      } // Track pT loop
    } // Jet pT loop
  } // Jet energy scale uncertainty

  // ============================================================= //
  //   Uncertainty coming from number of iterations in unfolding   //
  // ============================================================= //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingIterations]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kUnfoldingIterations] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], unfoldingIterationsUncertaintyCorrelators[iJetPt][iTrackPt], 2);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kUnfoldingIterations] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
          legendNames[0] = "Unfolding with 3 iterations";
          legendNames[1] = "Unfolding with 5 iterations";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.97,1.03);
          }


          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], unfoldingIterationsUncertaintyCorrelators[iJetPt][iTrackPt], 2, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kUnfoldingIterations), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }
      
      } // Track pT loop
    } // Jet pT loop
  } // Jet energy scale uncertainty

  // ================================================== //
  //   Uncertainty coming from background subtraction   //
  // ================================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kBackgroundSubtraction]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kBackgroundSubtraction] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], backgroundSubtractionUncertaintyCorrelators[iJetPt][iTrackPt]);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kBackgroundSubtraction] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)) {
          legendNames[0] = "Bg from peripharal P+H";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.97,1.03);
          }

          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], backgroundSubtractionUncertaintyCorrelators[iJetPt][iTrackPt], iJetPt, iTrackPt, nominalResultCard, legendNames[0], nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kBackgroundSubtraction), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }

      } // Track pT loop
    } // Jet pT loop
  } // Background subtraction uncertainty

  // =============================================== //
  //     Uncertainty coming from track selection     //
  // =============================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackSelection]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackSelection] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], trackSelectionUncertaintyCorrelators[iJetPt][iTrackPt], 2);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kTrackSelection] &&  std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
          legendNames[0] = "Loose track selection";
          legendNames[1] = "Tight track selection";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.8,1.2);
          }

          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], trackSelectionUncertaintyCorrelators[iJetPt][iTrackPt], 2, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kTrackSelection), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }
      
      } // Track pT loop
    } // Jet pT loop
  } // Track selection uncertainty

  // =================================================== //
  //   Uncertainty coming from single track efficiency   //
  // =================================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSingleTrackEfficiency]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kSingleTrackEfficiency] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], singleTrackEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt], 2);        

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kSingleTrackEfficiency] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)) {
          legendNames[0] = "Efficiency - 2.2%";
          legendNames[1] = "Efficiency + 2.2%";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.99999,1.00001);
          }

          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], singleTrackEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt], 2, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kSingleTrackEfficiency), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }

      } // Track pT loop
    } // Jet pT loop
  } // Track selection uncertainty

  // =================================================== //
  //    Uncertainty coming from track pair efficiency    //
  // =================================================== //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackPairEfficiency]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackPairEfficiency] = findTheDifference(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], trackPairEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt], 2);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kTrackPairEfficiency] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
          legendNames[0] = "Pair efficiency - 4.4%";
          legendNames[1] = "Pair efficiency + 4.4%";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.95,1.05);
          }

          drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], trackPairEfficiencyUncertaintyCorrelators[iJetPt][iTrackPt], 2, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kTrackPairEfficiency), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }

      } // Track pT loop
    } // Jet pT loop
  } // Track selection uncertainty

  // ======================================================================= //
  //   Uncertainty coming from limited statistics in the Monte Carlo sample  //
  // ======================================================================= //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloStatistics]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloStatistics] = findStandardDeviation(nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], monteCarloStatisticsUncertaintyCorrelators[iJetPt][iTrackPt], nMCStatisticsRandomizations);

        // Draw example plots on how the uncertainty is obtained
        if(plotExample[SystematicUncertaintyOrganizer::kMonteCarloStatistics] && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
          legendNames[0] = "Response matrix variations";

          // Set reasonable ratio zoom
          if(setAutomaticRatioZoom){
            ratioZoom = std::make_pair(0.95,1.05);
          }

          drawIllustratingPlotsMonochrome(drawer, nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], monteCarloStatisticsUncertaintyCorrelators[iJetPt][iTrackPt], nMCStatisticsRandomizations, iJetPt, iTrackPt, nominalResultCard, legendNames[0], nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kMonteCarloStatistics), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
        }
      
      } // Track pT loop
    } // Jet pT loop
  } // Uncertainty from limited statistics in Monte Carlo

  // ===================================================== //
  //   Uncertainty coming from non-closure in Monte Carlo  //
  // ===================================================== //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloNonClosure]){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        optimusPrimeTheTransformer->SuppressSingleBinFluctuations(energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloNonClosure], analysisDeltaR.first, analysisDeltaR.second, 3, 0.5);
        optimusPrimeTheTransformer->TransformToAbsoluteUncertainty(energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloNonClosure], nominalEnergyEnergyCorrelators[iJetPt][iTrackPt], false);

        // Note: Illustrating plots for this uncertainty can be plotter with fullAnalysisClosure.C macro
      
      } // Track pT loop
    } // Jet pT loop
  } // Jet energy scale uncertainty

  // ============================================= //
  //   Add all uncertainty sources in quadrature   //
  // ============================================= //
  
  double sumOfSquares;
  for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
    for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

      // Clone the uncertainty histogram from the nominal one
      energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kAll] = (TH1D*)nominalEnergyEnergyCorrelators[iJetPt][iTrackPt]->Clone(Form("summedUncertainty%d%d", iJetPt, iTrackPt));

      // Calculate a sum of squared from all evaluated uncertainties
      for(int iBin = 1; iBin <= nominalEnergyEnergyCorrelators[iJetPt][iTrackPt]->GetNbinsX(); iBin++){
        sumOfSquares = 0;
        for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::kAll; iUncertainty++) {
          if(energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][iUncertainty] != NULL) {
            sumOfSquares = sumOfSquares + TMath::Power(energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][iUncertainty]->GetBinError(iBin), 2);
          }
        }  // Uncertainty type loop
        energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kAll]->SetBinError(iBin, TMath::Sqrt(sumOfSquares));
      } // Bin loop
    } // Track pT loop
  } // Jet pT loop

  // =========================================================== //
  //   Write the systematic uncertainty histograms into a file   //
  // =========================================================== //
  
  // If an output file name is given, put the total uncertainties to an output file
  if(outputFileName.EndsWith(".root")){
    TFile* outputFile = new TFile(outputFileName,"UPDATE");
    TString saveName;

    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++) {
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++) {
        for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++) {
          if(energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][iUncertainty] != NULL) {
            saveName = Form("systematicUncertainty_%s_C0J%dT%d", nameGiver->GetSystematicUncertaintyName(iUncertainty).Data(), iJetPt, iTrackPt);
            energyEnergyCorrelatorSystematicUncertainties[iJetPt][iTrackPt][iUncertainty]->Write(saveName);
          }
        } // Uncertainty loop
      } // Track pT loop
    } // Jet pT loop

    // Write the card from the nominal file, since all indices are syncronized with that
    nominalResultCard->Write(outputFile);

    outputFile->Close();
  }
  
  // =========================================================================== //
  // Print slides summarizing all the different sources of systemtic uncertainty //
  // =========================================================================== //
  
  // if(printUncertainties){
    
  //   // Print a slide with uncertainties for each source and each centrality for each V
  //   char namer[100];
  //   for(int iFlow = firstFlow-1; iFlow <= lastFlow-1; iFlow++){
      
  //     sprintf(namer,"\\frametitle{Uncertainty for jet $v_{%d}$}", iFlow+1);
      
  //     cout << endl;
  //     cout << "\\begin{frame}" << endl;
  //     cout << namer << endl;
  //     cout << "\\begin{center}" << endl;
  //     cout << "  \\begin{tabular}{cccccc}" << endl;
  //     cout << "    \\toprule" << endl;
  //     cout << "    Source & C: 0-10 & C: 10-30 & C: 30-50 \\\\" << endl;
  //     cout << "    \\midrule" << endl;
      
  //     // Set the correct precision for printing floating point numbers
  //     cout << fixed << setprecision(4);
      
  //     // First, print the actual values of vn:s
  //     cout << "$v_{" << iFlow+1 << "}$ ";
      
  //     for(int iCentrality = 0; iCentrality < nCentralityBins; iCentrality++){
  //       nominalResultGraph[iFlow]->GetPoint(iCentrality, nominalX, nominalY);
  //       cout << " & $" << nominalY << "$";
  //     }
  //     cout << " \\\\" << endl;
  //     cout << "    \\midrule" << endl;
      
  //     // Print the relative uncertainties
      
  //     for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
  //       cout << uncertaintyNamer->GetLongRangeUncertaintyName(iUncertainty).Data();
  //       for(int iCentrality = 0; iCentrality < nCentralityBins; iCentrality++){
  //         cout << " & $" << relativeUncertaintyTable[iUncertainty][iFlow][iCentrality] << "$";
  //       }
  //       cout << " \\\\" << endl;
  //     }
      
  //     cout << "    \\midrule" << endl;
      
  //     // Print the absolute uncertainties
      
  //     for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
  //       cout << uncertaintyNamer->GetLongRangeUncertaintyName(iUncertainty).Data();
  //       for(int iCentrality = 0; iCentrality < nCentralityBins; iCentrality++){
  //         cout << " & $" << absoluteUncertaintyTable[iUncertainty][iFlow][iCentrality] << "$";
  //       }
  //       cout << " \\\\" << endl;
  //     }
      
      
  //     cout << "    \\bottomrule" << endl;
  //     cout << "  \\end{tabular}" << endl;
  //     cout << "\\end{center}" << endl;
  //     cout << "\\begin{itemize}" << endl;
  //     cout << "  \\item Top: value. Middle: relative uncertainty. Bottom: absolute uncertainty." << endl;
  //     cout << "\\end{itemize}" << endl;
  //     cout << "\\end{frame}" << endl;
  //     cout << endl;
      
  //   } // vn loop
    
  // } // Printing uncertainties
}

/*
 * Function for finding the relative and absolute difference of points in two graphs
 *
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histograms containing varied results for systematic uncertainty estimation
 *  const int nVariations = Number of variations used to estimate the systematic uncertainties
 *
 *  return: Histogram where the error bars in each point correspond to estimated systematic uncertainty
 *
 */
TH1D* findTheDifference(TH1D *nominalResult, TH1D *variedResult[], const int nVariations){
  
  // Create an uncertainty histogram from the nominal results
  TH1D* uncertaintyHistogram = (TH1D*) nominalResult->Clone(Form("uncertaintyFor%s", variedResult[0]->GetName()));
  
  // Loop over the bins in the histogram, and in each bin assign the greates variation from the nominal result as uncertainty
  double biggestDifference, currentDifference;
  for(int iBin = 1; iBin <= nominalResult->GetNbinsX(); iBin++){
    biggestDifference = 0;
    for(int iVariation = 0; iVariation < nVariations; iVariation++){
      currentDifference = TMath::Abs(nominalResult->GetBinContent(iBin) - variedResult[iVariation]->GetBinContent(iBin));
      if(currentDifference > biggestDifference) biggestDifference = currentDifference;
    }
    uncertaintyHistogram->SetBinError(iBin, biggestDifference);
  } // Histogram bin loop
  
  // Return the histogram where the errors represent the systematic uncertainties
  return uncertaintyHistogram;
  
}

/*
 * Function for finding the realtive and absolute difference of points in two graphs
 *
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histogram containing varied results for systematic uncertainty estimation
 *
 *  return: Histogram where the error bars in each point correspond to estimated systematic uncertainty
 *
 */
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult){
  
  // Enclose the single graph to an array and use the difference finder for graph array
  TH1D* comparisonArray[1] = {variedResult};
  return findTheDifference(nominalResult, comparisonArray, 1);
  
}

/*
 * Function for finding standard deviation from a set of varied results
 *
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histograms containing varied results for systematic uncertainty estimation
 *  const int nVariations = Number of variations used to estimate the systematic uncertainties
 *
 *  return: Histogram where the error bars in each point correspond to estimated systematic uncertainty
 *
 */
TH1D* findStandardDeviation(TH1D* nominalResult, TH1D* variedResult[], const int nVariations){
  
  // Create an uncertainty histogram from the nominal results
  TH1D* uncertaintyHistogram = (TH1D*) nominalResult->Clone(Form("uncertaintyFor%s", variedResult[0]->GetName()));
  
  // In each bin, assign the systematic uncertainty to be the standard deviation of varied results
  double meanValue;
  double standardDeviation;
  for(int iBin = 1; iBin <= nominalResult->GetNbinsX(); iBin++){

    // First, calculate the mean value of the varied results.
    meanValue = 0;
    for(int iVariation = 0; iVariation < nVariations; iVariation++){
      meanValue += variedResult[iVariation]->GetBinContent(iBin);
    }
    meanValue /= nVariations;

    // After we have the mean value, we can calculate stadard deviation
    standardDeviation = 0;
    for(int iVariation = 0; iVariation < nVariations; iVariation++){
      standardDeviation += TMath::Power(variedResult[iVariation]->GetBinContent(iBin) - meanValue, 2);
    }
    standardDeviation = TMath::Sqrt(standardDeviation / nVariations);

    uncertaintyHistogram->SetBinError(iBin, standardDeviation);
  } // Histogram bin loop
  
  // Return the histogram where the errors represent the systematic uncertainties
  return uncertaintyHistogram;
  
}

/*
 * Draw plots illustrating how systematic uncertainties are estimated form a certain source
 *
 *  JDrawer *drawer = JDrawer doing the dirty work in drawing
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult[] = Array of histograms containing variation of results around the nominal one
 *  const int nVariations = Number of variations around the nominal result
 *  const int iJetPt = Jet pT index of the considered bin
 *  const int iTrackPt = Track pT index of the considered bin
 *  EECCard* card = Card used to interpret the bin index
 *  TString comparisonLegend[] = An array of strings describing each result variation
 *  TString plotName = String added to saved plots. If left empty, the plots are not saved into files.
 *  TString plotComment = Comment given to the saved plots
 *  std::pair<double, double> drawingRange = Drawing range for x-axis
 *  std::pair<double, double> ratioZoom = Y-axis zoom for the ratio
 */
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend[], TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom){
  
  const int markers[] = {kFullDiamond, kFullDoubleDiamond, kFullCross, kFullFourTrianglesPlus, kFullSquare, kFullStar};
  const int colors[] = {kBlue, kRed, kGreen+3, kMagenta, kCyan, kViolet, kBlack};
  
  // Interpret the given binning information
  TString jetPtString = Form("%.0f < jet p_{T} < %.0f", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString compactJetPtString = Form("_J=%.0f-%.0f", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString trackPtString = Form("%.1f < track p_{T}",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  TString compactTrackPtString = Form("_T>%.1f",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  compactTrackPtString.ReplaceAll(".","v");

  // Calculate ratios between nominal and comparison graphs
  TH1D *ratioHistogram[nVariations];
  for(int iVariation = 0; iVariation < nVariations; iVariation++){
    ratioHistogram[iVariation] = (TH1D*) variedResult[iVariation]->Clone(Form("ratio_%s", comparisonLegend[iVariation].Data()));
    ratioHistogram[iVariation]->Divide(nominalResult);
  } // Varied results loop

  // Create a new canvas for the plot
  drawer->CreateSplitCanvas();

  // Use logarithmic axis for EEC
  drawer->SetLogY(true);

  // Check from plot comment if we need to also add another line to the legend
  bool hasHigherWeightExponent = (plotComment == "_energyWeightSquared");

  // Setup the legend for plots
  TLegend *legend = new TLegend(0.23,0.23-nVariations*0.06,0.46,0.6);
  legend->SetFillStyle(0);legend->SetBorderSize(0);legend->SetTextSize(0.05);legend->SetTextFont(62);
  legend->AddEntry((TObject*) 0, Form("%s 5.02 TeV",card->GetAlternativeDataType().Data()), "");
  if(hasHigherWeightExponent) legend->AddEntry((TObject*) 0, "Energy weight squared","");
  legend->AddEntry((TObject*) 0, jetPtString.Data(),"");
  legend->AddEntry((TObject*) 0, trackPtString.Data(),"");

  // Set the x-axis drawing range
  nominalResult->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  // Draw the nominal result to the upper canvas
  nominalResult->SetLineColor(kBlack);
  drawer->DrawHistogramToUpperPad(nominalResult, "#Deltar", "EEC Signal", " ");
  legend->AddEntry(nominalResult, "Nominal", "l");

  // Draw the variations to the same plot
  for(int iVariation = 0; iVariation < nVariations; iVariation++) {
    variedResult[iVariation]->SetLineColor(colors[iVariation]);
    variedResult[iVariation]->Draw("same");
    legend->AddEntry(variedResult[iVariation], comparisonLegend[iVariation], "l");
  }

  // Draw the legends to the upper pad
  legend->Draw();

  // Linear scale for the ratio
  drawer->SetLogY(false);

  // Set the x-axis drawing range
  ratioHistogram[0]->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  ratioHistogram[0]->SetLineColor(colors[0]);
  ratioHistogram[0]->GetYaxis()->SetRangeUser(ratioZoom.first, ratioZoom.second);
  drawer->SetGridY(true);
  drawer->DrawHistogramToLowerPad(ratioHistogram[0], "#Deltar", "#frac{Variation}{Nominal}", " ");
  for(int iVariation = 1; iVariation < nVariations; iVariation++) {
    ratioHistogram[iVariation]->SetLineColor(colors[iVariation]);
    ratioHistogram[iVariation]->Draw("same");
  }
  drawer->SetGridY(false);
  
  // If a plot name is given, save the plot in a file
  if(plotName != ""){
    gPad->GetCanvas()->SaveAs(Form("figures/systematicUncertainty_%s_pp%s%s%s.pdf", plotName.Data(), plotComment.Data(), compactJetPtString.Data(), compactTrackPtString.Data()));
  }
}

/*
 * Draw plots illustrating how systematic uncertainties are estimated form a certain source
 *
 *  JDrawer* drawer = JDrawer doing the dirty work in drawing
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histogram containing variation of results around the nominal one
 *  const int iJetPt = Jet pT index of the considered bin
 *  const int iTrackPt = Track pT index of the considered bin
 *  EECCard* card = Card used to interpret the binning information
 *  TString comparisonLegend = String describing the variation
 *  TString plotName = String added to saved plots. If left empty, the plots are not saved into files.
 *  TString plotComment = Comment given to the saved plots
 *  std::pair<double, double> drawingRange = Drawing range for x-axis
 *  std::pair<double, double> ratioZoom = Y-axis zoom for the ratio
 */
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom){
  TH1D* variedResultArray[1] = {variedResult};
  TString comparisonLegendArray[1] = {comparisonLegend};
  drawIllustratingPlots(drawer, nominalResult, variedResultArray, 1, iJetPt, iTrackPt, card, comparisonLegendArray, plotName, plotComment, drawingRange, ratioZoom);
}

/*
 * Draw plots illustrating how systematic uncertainties are estimated form a certain source
 *
 *  JDrawer* drawer = JDrawer doing the dirty work in drawing
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult[] = Array of histograms containing variation of results around the nominal one
 *  const int nVariations = Number of variations around the nominal result
 *  const int iJetPt = Jet pT index of the considered bin
 *  const int iTrackPt = Track pT index of the considered bin
 *  EECCard* card = Card used to interpret the bin index
 *  TString comparisonLegend = An array of strings describing each result variation
 *  TString plotName = String added to saved plots. If left empty, the plots are not saved into files.
 *  TString plotComment = Comment given to the saved plots
 *  std::pair<double, double> drawingRange = Drawing range for x-axis
 *  std::pair<double, double> ratioZoom = Y-axis zoom for the ratio
 */
void drawIllustratingPlotsMonochrome(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom){
  
  // Interpret the given binning information
  TString jetPtString = Form("%.0f < jet p_{T} < %.0f GeV", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString compactJetPtString = Form("_J=%.0f-%.0f", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString trackPtString = Form("p_{T}^{ch} > %.1f GeV",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  TString compactTrackPtString = Form("_T>%.1f",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  compactTrackPtString.ReplaceAll(".","v");

  // Calculate ratios between nominal and comparison graphs
  TH1D *ratioHistogram[nVariations];
  for(int iVariation = 0; iVariation < nVariations; iVariation++){
    ratioHistogram[iVariation] = (TH1D*) variedResult[iVariation]->Clone(Form("ratio%d_%s", iVariation, comparisonLegend.Data()));
    ratioHistogram[iVariation]->Divide(nominalResult);
  } // Varied results loop

  // Create a new canvas for the plot
  drawer->CreateSplitCanvas();

  // Use logarithmic axis for EEC
  drawer->SetLogY(true);

  // Check from plot comment if we need to also add another line to the legend
  int weightExponent = (plotComment == "_energyWeightSquared") + 1;

  // Setup the legend for plots
  TLegend *legend = new TLegend(0.23,0.08,0.46,0.6);
  legend->SetFillStyle(0);legend->SetBorderSize(0);legend->SetTextSize(0.05);legend->SetTextFont(62);
  legend->AddEntry((TObject*) 0, Form("%s 5.02 TeV",card->GetAlternativeDataType().Data()), "");
  legend->AddEntry((TObject*) 0, Form("n = %d", weightExponent),"");
  legend->AddEntry((TObject*) 0, jetPtString.Data(),"");
  legend->AddEntry((TObject*) 0, trackPtString.Data(),"");

  // Set the x-axis drawing range
  nominalResult->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  // Draw the nominal result to the upper canvas
  nominalResult->SetLineColor(kBlack);
  drawer->DrawHistogramToUpperPad(nominalResult, "#Deltar", "EEC Signal", " ");
  legend->AddEntry(nominalResult, "Nominal", "l");

  // Draw the variations to the same plot
  for(int iVariation = 0; iVariation < nVariations; iVariation++) {
    variedResult[iVariation]->SetLineColor(kBlue);
    variedResult[iVariation]->Draw("same");
  }
  legend->AddEntry(variedResult[0], comparisonLegend, "l");

  // Draw the legends to the upper pad
  legend->Draw();

  // Linear scale for the ratio
  drawer->SetLogY(false);

  // Set the x-axis drawing range
  ratioHistogram[0]->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  ratioHistogram[0]->SetLineColor(kBlue);
  ratioHistogram[0]->GetYaxis()->SetRangeUser(ratioZoom.first, ratioZoom.second);
  drawer->SetGridY(true);
  drawer->DrawHistogramToLowerPad(ratioHistogram[0], "#Deltar", "#frac{Variation}{Nominal}", " ");
  for(int iVariation = 1; iVariation < nVariations; iVariation++) {
    ratioHistogram[iVariation]->SetLineColor(kBlue);
    ratioHistogram[iVariation]->Draw("same");
  }
  drawer->SetGridY(false);
  
  // If a plot name is given, save the plot in a file
  if(plotName != ""){
    gPad->GetCanvas()->SaveAs(Form("figures/systematicUncertainty_%s_pp%s%s%s.pdf", plotName.Data(), plotComment.Data(), compactJetPtString.Data(), compactTrackPtString.Data()));
  }
}