#include "SystematicUncertaintyOrganizer.h" R__LOAD_LIBRARY(plotting/DrawingClasses.so)
#include "EECCard.h"
#include "EECHistogramManager.h"
#include "JDrawer.h"
#include "AlgorithmLibrary.h"

#include <algorithm>

// Function definitions. Implementations after the main macro.
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult[], const int nComparisonGraphs, const int ignoreIndex);
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult[], const int nComparisonGraphs);
TH1D* findStandardDeviation(TH1D* nominalResult, TH1D* variedResult[], const int nComparisonGraphs);
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult);
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iCentrality, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend[], TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom);
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult, const int iCentrality, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom);
void drawIllustratingPlotsMonochrome(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iCentrality, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom);

/*
 * Macro for estimating systematic uncertainties for energy-energy correlators
 *
 * The following sources of systematic uncertainty are estimated:
 *  - Jet energy resolition uncertainty (modifies unfolding response matrix, correlated)
 *  - Jet energy scale uncertainty (modifies unfolding response matrix, correlated)
 *  - Truth reference for jet pT unfolding (modifies unfolding response matrix, correlated)
 *  - Tracking efficiency (uncorrelated)
 *  - Track pair efficiency (uncorrelated)
 *  - Background subtraction (uncorrelated)
 *
 *  The results will be saved to a file and also slides with different contributions can be printed
 *
 * Arguments:
 *  const int weightExponent = Exponents for the energy weight in energy-energy correlators. Currently 1 and 2 are implemented.
 */
void estimateSystematicUncertainties(const int weightExponent = 1){

  // First, do a sanity check for the weight exponents. Currently only 1 and 2 are implemented.
  if(weightExponent < 1 || weightExponent > 2){
    cout << "ERROR! The weight exponent you gave has not been implemented!" << endl;
    cout << "Currently only values 1 and 2 are implemented." << endl;
    cout << "Please select one of these values for weight exponent." << endl;
    return;
  }

  TString weightExponentString[2];
  weightExponentString[0] = "nominalEnergyWeight";
  weightExponentString[1] = "energyWeightSquared";

  // For tracking efficiencies and selections, we do not have the same amount of mixed events available as for default results.
  // In order to avoid folding different mixing statistics into systematic uncertainties, in these cases for the final
  // uncertainty file we can read directly the relative uncertainty determined from a case where the backgrounds are identical.
  const bool readRelativeUncertaintyForTracking = true;
  
  // ==================================================================
  // ============================= Input ==============================
  // ==================================================================

  // Nominal results
  TString nominalResultFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_combinedMixedConeBackground_unfoldingWithNominalSmear_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_combinedMixedConeBackground_unfoldingWithNominalSmear_processed_2024-05-28.root"};
  //TString nominalResultFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_reflectedConeBackground_unfoldingWithNominalSmear_processed_2024-04-17.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_reflectedConeBackground_unfoldingWithNominalSmear_processed_2024-04-17.root"}; // Result files for track selection uncertainties
  TFile* nominalResultFile = TFile::Open(nominalResultFileName[weightExponent-1]);
  EECCard* nominalResultCard = new EECCard(nominalResultFile);
  EECHistogramManager* nominalHistogramManager = new EECHistogramManager(nominalResultFile, nominalResultCard);
  
  // Results unfolded with a response matrix smeared with jet energy resolution
  TString jetEnergyResolutionSmearDownFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWithUncertaintySmearDown_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWithUncertaintySmearDown_processed_2024-05-28.root"};
  TString jetEnergyResolutionSmearUpFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWithUncertaintySmearUp_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWithUncertaintySmearUp_processed_2024-05-28.root"};
  TString jetEnergyResolutionFileName[2];
  jetEnergyResolutionFileName[0] = jetEnergyResolutionSmearDownFileName[weightExponent-1];
  jetEnergyResolutionFileName[1] = jetEnergyResolutionSmearUpFileName[weightExponent-1];
  TFile* jetEnergyResolutionFile[2];
  EECCard* jetEnergyResolutionCard[2];
  EECHistogramManager* jetEnergyResolutionHistogramManager[2];
  
  // Results unfolded with a response matrix smeared with jet energy scale
  TString jetEnergyScaleMinusFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWithMinusJetEnergyScale_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWithMinusJetEnergyScale_processed_2024-05-28.root"};
  TString jetEnergyScalePlusFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWithPlusJetEnergyScale_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWithPlusJetEnergyScale_processed_2024-05-28.root"};
  TString jetEnergyScaleFileName[2];
  jetEnergyScaleFileName[0] = jetEnergyScaleMinusFileName[weightExponent-1];
  jetEnergyScaleFileName[1] = jetEnergyScalePlusFileName[weightExponent-1];
  TFile* jetEnergyScaleFile[2];
  EECCard* jetEnergyScaleCard[2];
  EECHistogramManager* jetEnergyScaleHistogramManager[2];

  // Results unfolded with a response matrix where jet pT spectrum is weighted to match the data
  TString jetPtPriorFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWithModifiedPrior_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWithModifiedPrior_processed_2024-05-28.root"};
  TFile* jetPtPriorFile;
  EECCard* jetPtPriorCard;
  EECHistogramManager* jetPtPriorHistogramManager;

  // Results unfolded with a different number of iterations compared to nominal results
  TString unfoldingIterationsMinusFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWith3Iterations_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWith3Iterations_processed_2024-05-28.root"};
  TString unfoldingIterationsPlusFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWith5Iterations_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWith5Iterations_processed_2024-05-28.root"};
  TString unfoldingIterationsFileName[2];
  unfoldingIterationsFileName[0] = unfoldingIterationsMinusFileName[weightExponent-1];
  unfoldingIterationsFileName[1] = unfoldingIterationsPlusFileName[weightExponent-1];
  TFile* unfoldingIterationsFile[2];
  EECCard* unfoldingIterationsCard[2];
  EECHistogramManager* unfoldingIterationsHistogramManager[2];

  // Results obtained with reflected cone background subtraction method
  TString reflectedConeFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_reflectedConeBackground_unfoldingWithNominalSmear_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_reflectedConeBackground_unfoldingWithNominalSmear_processed_2024-05-28.root"};
  TFile* backgroundSubtractionFile;
  EECCard* backgroundSubtractionCard;
  EECHistogramManager* backgroundSubtractionHistogramManager;

  // Results with varied signal-to-background ratios after unfolding
  TString signalToBackgroundRatioLowScaleFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWithNominalSmear_lowSignalToBackgroundScaleEstimateAfterUnfolding_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWithNominalSmear_lowSignalToBackgroundScaleEstimateAfterUnfolding_processed_2024-05-28.root"};
  TString signalToBackgroundRatioHighScaleFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWithNominalSmear_highSignalToBackgroundScaleEstimateAfterUnfolding_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWithNominalSmear_highSignalToBackgroundScaleEstimateAfterUnfolding_processed_2024-05-28.root"};
  TString signalToBackgroundRatioFileName[2];
  signalToBackgroundRatioFileName[0] = signalToBackgroundRatioLowScaleFileName[weightExponent-1];
  signalToBackgroundRatioFileName[1] = signalToBackgroundRatioHighScaleFileName[weightExponent-1];
  TFile* signalToBackgroundRatioFile[2];
  EECCard* signalToBackgroundRatioCard[2];
  EECHistogramManager* signalToBackgroundRatioHistogramManager[2];

  // Result with different track selections
  TString looseTrackSelectionFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_optimizedUnfoldingBins_looseTrackCuts_processed_2024-04-17.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_optimizedUnfoldingBins_looseTrackCuts_processed_2024-04-17.root"};
  TString tightTrackSelectionFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_optimizedUnfoldingBins_tightTrackCuts_processed_2024-04-17.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_optimizedUnfoldingBins_tightTrackCuts_processed_2024-04-17.root"};
  TString trackSelectionFileName[2];
  trackSelectionFileName[0] = looseTrackSelectionFileName[weightExponent-1];
  trackSelectionFileName[1] = tightTrackSelectionFileName[weightExponent-1];
  TFile* trackSelectionFile[2];
  EECCard* trackSelectionCard[2];
  EECHistogramManager* trackSelectionHistogramManager[2];

  // We do not have excessive amounts of mixing for different track selections and efficiencies. Thus, in these cases use
  // the relative uncertainty determined from a file where we have exactly the same background. Otherwise different
  // background statistics will add into the systematic uncertainty estimate.
  TString relativeUncertaintyFileName[2] = {"systematicUncertainties/systematicUncertainties_PbPb_nominalEnergyWeight_mixedConeBackground_noMCnonClosure_2024-05-02.root", "systematicUncertainties/systematicUncertainties_PbPb_energyWeightSquared_mixedConeBackground_noMCnonClosure_2024-05-02.root"};
  TFile* relativeUncertaintyFile = TFile::Open(relativeUncertaintyFileName[weightExponent-1]);
  EECCard* relativeUncertaintyCard = new EECCard(relativeUncertaintyFile);

  // Results with varied single and pair track efficiency
  TString trackEfficiencyFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_trackSystematics_processed_2024-04-17.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_trackSystematics_processed_2024-04-17.root"};
  TFile* trackEfficiencyFile;
  EECCard* trackEfficiencyCard;
  EECHistogramManager* trackEfficiencyHistogramManager;

  // Results where the jet pT response matrix is determined from 2% or 6% shifted simulation instead of nominal 4%
  TString centralityShift2pFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWith2pCentShift_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWith2pCentShift_processed_2024-05-28.root"};
  TString centralityShift6pFileName[2] = {"data/eecAnalysis_akFlowJet_nominalEnergyWeight_mixedConeBackground_unfoldingWith6pCentShift_processed_2024-05-28.root", "data/eecAnalysis_akFlowJet_energyWeightSquared_mixedConeBackground_unfoldingWith6pCentShift_processed_2024-05-28.root"};
  TString centralityShiftFileName[2];
  centralityShiftFileName[0] = centralityShift2pFileName[weightExponent-1];
  centralityShiftFileName[1] = centralityShift6pFileName[weightExponent-1];
  TFile* centralityShiftFile[2];
  EECCard* centralityShiftCard[2];
  EECHistogramManager* centralityShiftHistogramManager[2];

  // Results where the unfolding has been done with randomized response matrices to evaluate MC statistics uncertainty
  const int nMCStatisticsRandomizations = 50;
  TString mcStatisticsFileName[nMCStatisticsRandomizations];
  for(int iVariation = 0; iVariation < nMCStatisticsRandomizations; iVariation++){
    mcStatisticsFileName[iVariation] = Form("data/mcStatisticsRandomization/eecAnalysis_akFlowJet_%s_combinedBackground_mcStatisticsUncertaintyRandom%d_processed_2025-04-16.root", weightExponentString[weightExponent-1].Data(), iVariation+1);
  }
  TFile* mcStatisticsFile[nMCStatisticsRandomizations];
  EECCard* mcStatisticsCard[nMCStatisticsRandomizations];
  EECHistogramManager* mcStatisticsHistogramManager[nMCStatisticsRandomizations];

  // File containing relative uncertainties resulting from Monte Carlo non-closure
  TString monteCarloNonClosureFileName[2] = {"systematicUncertainties/monteCarloNonClosureRelative_PbPb_nominalEnergyWeight_2024-02-23.root", "systematicUncertainties/monteCarloNonClosureRelative_PbPb_energyWeightSquared_2024-02-23.root"};
  TFile* monteCarloNonClosureFile = TFile::Open(monteCarloNonClosureFileName[weightExponent-1]);
  EECCard* monteCarloNonClosureCard = new EECCard(monteCarloNonClosureFile);
  
  // ==================================================================
  // ========================= Configuration ==========================
  // ==================================================================
  
  // Find the number of bins from the card
  const int nCentralityBins = nominalResultCard->GetNCentralityBins();
  const int nJetPtBinsEEC = nominalResultCard->GetNJetPtBinsEEC();
  const int nTrackPtBinsEEC = nominalResultCard->GetNTrackPtBinsEEC();
  
  // Estimate the uncertainties for all bins that have been unfolded
  int firstStudiedCentralityBin = nominalResultCard->GetFirstUnfoldedCentralityBin();
  int lastStudiedCentralityBin = nominalResultCard->GetLastUnfoldedCentralityBin();
  
  int firstStudiedJetPtBinEEC = nominalResultCard->GetFirstUnfoldedJetPtBin();
  int lastStudiedJetPtBinEEC = nominalResultCard->GetLastUnfoldedJetPtBin();
  
  int firstStudiedTrackPtBinEEC = nominalResultCard->GetFirstUnfoldedTrackPtBin();
  int lastStudiedTrackPtBinEEC = nominalResultCard->GetLastUnfoldedTrackPtBin();

  // Only draw example plots from selected subset of bins
  vector<int> drawnCentralityBins = {0,1,2,3};
  vector<int> drawnJetPtBins = {5,6,7,8};
  vector<int> drawnTrackPtBins = {1,3,5};

  const int twoGeVBin = nominalResultCard->GetBinIndexTrackPtEEC(2);
  
  const bool printUncertainties = false;
  
  std::pair<double, double> analysisDeltaR = std::make_pair(0.008, 0.39); // DeltaR span in which the analysis is done
  std::pair<double, double> ratioZoom = std::make_pair(0.8, 1.2);         // Y-axis zoom for ratios
  bool setAutomaticRatioZoom = true;                                      // If true, use predefined ratio zooms for systematic uncertainties

  // Transformer used for Monte Carlo non-closure uncertainty
  AlgorithmLibrary* optimusPrimeTheTransformer = new AlgorithmLibrary();
  TString today = optimusPrimeTheTransformer->GetToday();
  
  TString nameAdder[] = {"_nominalEnergyWeight","_energyWeightSquared"}; 
  TString outputFileName = Form("systematicUncertainties/systematicUncertainties_PbPb%s_combinedMxedConeBackground_includeMCstats_%s.root", nameAdder[weightExponent-1].Data(), today.Data());
  //TString outputFileName = Form("systematicUncertainties/lul_PbPb%s_dummyFile_%s.root", nameAdder[weightExponent-1].Data(), today.Data());
  
  // Option to skip evaluating some of the sources defined in SystematicUncertaintyOrganizer or not plotting examples of some
  // The different options are:
  // SystematicUncertaintyOrganizer::kJetEnergyResolution
  // SystematicUncertaintyOrganizer::kJetEnergyScale
  // SystematicUncertaintyOrganizer::kUnfoldingTruth
  // SystematicUncertaintyOrganizer::kUnfoldingIterations
  // SystematicUncertaintyOrganizer::kBackgroundSubtraction
  // SystematicUncertaintyOrganizer::kSignalToBackgroundRatio
  // SystematicUncertaintyOrganizer::kTrackSelection
  // SystematicUncertaintyOrganizer::kSingleTrackEfficiency
  // SystematicUncertaintyOrganizer::kTrackPairEfficiency
  // SystematicUncertaintyOrganizer::kCentralityShift
  // SystematicUncertaintyOrganizer::kMonteCarloStatistics
  // SystematicUncertaintyOrganizer::kMonteCarloNonClosure
  bool skipUncertaintySource[SystematicUncertaintyOrganizer::knUncertaintySources];
  bool plotExample[SystematicUncertaintyOrganizer::knUncertaintySources];
  for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
    skipUncertaintySource[iUncertainty] = false;
    plotExample[iUncertainty] = false;
  }
  skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloNonClosure] = true;
  //skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloStatistics] = false;
  //plotExample[SystematicUncertaintyOrganizer::kMonteCarloStatistics] = true;
  
  // ==================================================================
  // ====================== Configuration done ========================
  // ==================================================================
  
  // Systematic uncertainty organizer can easily provide names for all your naming purposes
  SystematicUncertaintyOrganizer* nameGiver = new SystematicUncertaintyOrganizer();
  
  // Histograms for uncertainty estimation
  TH1D* nominalEnergyEnergyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC];
  TH1D* jetEnergyResolutionUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* jetEnergyScaleUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* jetPtPriorUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC];
  TH1D* unfoldingIterationsUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* backgroundSubtractionUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC];
  TH1D* signalToBackgroundRatioUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* trackSelectionUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* singleTrackEfficiencyUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* trackPairEfficiencyUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* centralityShiftUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][2];
  TH1D* monteCarloStatisticsUncertaintyCorrelators[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][nMCStatisticsRandomizations];
  TH1D* twoGeVRelativeHistogram;
  TH1D* currentRelativeHistogram;

  // Histograms to hold the systematic uncertainty results
  TH1D* energyEnergyCorrelatorSystematicUncertainties[nCentralityBins][nJetPtBinsEEC][nTrackPtBinsEEC][SystematicUncertaintyOrganizer::knUncertaintySources];
  
  // Initialize all the histograms to NULL
  for(int iCentrality = 0; iCentrality < nCentralityBins; iCentrality++){
    for(int iJetPt = 0; iJetPt < nJetPtBinsEEC; iJetPt++){
      for(int iTrackPt = 0; iTrackPt < nTrackPtBinsEEC; iTrackPt++){
        nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt] = NULL;
        jetPtPriorUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt] = NULL;
        backgroundSubtractionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt] = NULL;
        for(int iFile = 0; iFile < 2; iFile++){
          jetEnergyResolutionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
          jetEnergyScaleUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
          unfoldingIterationsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
          signalToBackgroundRatioUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
          trackSelectionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
          singleTrackEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
          trackPairEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
          centralityShiftUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
        }
        for(int iFile = 0; iFile < nMCStatisticsRandomizations; iFile++){
          monteCarloStatisticsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = NULL;
        }
        for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][iUncertainty] = NULL;
        }
      }
    }
  }

  // Load histograms only from files which are not skipped
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyResolution]){
    for(int iJetEnergyResolutionFile = 0; iJetEnergyResolutionFile < 2; iJetEnergyResolutionFile++){
      jetEnergyResolutionFile[iJetEnergyResolutionFile] = TFile::Open(jetEnergyResolutionFileName[iJetEnergyResolutionFile]);
      jetEnergyResolutionCard[iJetEnergyResolutionFile] = new EECCard(jetEnergyResolutionFile[iJetEnergyResolutionFile]);
      jetEnergyResolutionHistogramManager[iJetEnergyResolutionFile] = new EECHistogramManager(jetEnergyResolutionFile[iJetEnergyResolutionFile], jetEnergyResolutionCard[iJetEnergyResolutionFile]);
    }
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyScale]){
    for(int iJetEnergyScaleFile = 0; iJetEnergyScaleFile < 2; iJetEnergyScaleFile++){
      jetEnergyScaleFile[iJetEnergyScaleFile] = TFile::Open(jetEnergyScaleFileName[iJetEnergyScaleFile]);
      jetEnergyScaleCard[iJetEnergyScaleFile] = new EECCard(jetEnergyScaleFile[iJetEnergyScaleFile]);
      jetEnergyScaleHistogramManager[iJetEnergyScaleFile] = new EECHistogramManager(jetEnergyScaleFile[iJetEnergyScaleFile], jetEnergyScaleCard[iJetEnergyScaleFile]);
    }
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingIterations]){
    for(int iUnfoldingIterationsFile = 0; iUnfoldingIterationsFile < 2; iUnfoldingIterationsFile++){
      unfoldingIterationsFile[iUnfoldingIterationsFile] = TFile::Open(unfoldingIterationsFileName[iUnfoldingIterationsFile]);
      unfoldingIterationsCard[iUnfoldingIterationsFile] = new EECCard(unfoldingIterationsFile[iUnfoldingIterationsFile]);
      unfoldingIterationsHistogramManager[iUnfoldingIterationsFile] = new EECHistogramManager(unfoldingIterationsFile[iUnfoldingIterationsFile], unfoldingIterationsCard[iUnfoldingIterationsFile]);
    }
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingTruth]){
    jetPtPriorFile = TFile::Open(jetPtPriorFileName[weightExponent-1]);
    jetPtPriorCard = new EECCard(jetPtPriorFile);
    jetPtPriorHistogramManager = new EECHistogramManager(jetPtPriorFile, jetPtPriorCard);
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kBackgroundSubtraction]){
    backgroundSubtractionFile = TFile::Open(reflectedConeFileName[weightExponent-1]);
    backgroundSubtractionCard = new EECCard(backgroundSubtractionFile);
    backgroundSubtractionHistogramManager = new EECHistogramManager(backgroundSubtractionFile, backgroundSubtractionCard);
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSignalToBackgroundRatio]){
    for(int iSignalToBackgroundRatioFile = 0; iSignalToBackgroundRatioFile < 2; iSignalToBackgroundRatioFile++){
      signalToBackgroundRatioFile[iSignalToBackgroundRatioFile] = TFile::Open(signalToBackgroundRatioFileName[iSignalToBackgroundRatioFile]);
      signalToBackgroundRatioCard[iSignalToBackgroundRatioFile] = new EECCard(signalToBackgroundRatioFile[iSignalToBackgroundRatioFile]);
      signalToBackgroundRatioHistogramManager[iSignalToBackgroundRatioFile] = new EECHistogramManager(signalToBackgroundRatioFile[iSignalToBackgroundRatioFile], signalToBackgroundRatioCard[iSignalToBackgroundRatioFile]);
    }
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackSelection]){
    for(int iTrackSelectionFile = 0; iTrackSelectionFile < 2; iTrackSelectionFile++){
      trackSelectionFile[iTrackSelectionFile] = TFile::Open(trackSelectionFileName[iTrackSelectionFile]);
      trackSelectionCard[iTrackSelectionFile] = new EECCard(trackSelectionFile[iTrackSelectionFile]);
      trackSelectionHistogramManager[iTrackSelectionFile] = new EECHistogramManager(trackSelectionFile[iTrackSelectionFile], trackSelectionCard[iTrackSelectionFile]);
    }
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSingleTrackEfficiency] || !skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackPairEfficiency]){
    trackEfficiencyFile = TFile::Open(trackEfficiencyFileName[weightExponent-1]);
    trackEfficiencyCard = new EECCard(trackEfficiencyFile);
    trackEfficiencyHistogramManager = new EECHistogramManager(trackEfficiencyFile, trackEfficiencyCard);
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kCentralityShift]){
    for(int iCentralityShiftFile = 0; iCentralityShiftFile < 2; iCentralityShiftFile++){
      centralityShiftFile[iCentralityShiftFile] = TFile::Open(centralityShiftFileName[iCentralityShiftFile]);
      centralityShiftCard[iCentralityShiftFile] = new EECCard(centralityShiftFile[iCentralityShiftFile]);
      centralityShiftHistogramManager[iCentralityShiftFile] = new EECHistogramManager(centralityShiftFile[iCentralityShiftFile], centralityShiftCard[iCentralityShiftFile]);
    }
  }

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloStatistics]){
    for(int iMonteCarloStatisticsFile = 0; iMonteCarloStatisticsFile < nMCStatisticsRandomizations; iMonteCarloStatisticsFile++){
      mcStatisticsFile[iMonteCarloStatisticsFile] = TFile::Open(mcStatisticsFileName[iMonteCarloStatisticsFile]);
      mcStatisticsCard[iMonteCarloStatisticsFile] = new EECCard(mcStatisticsFile[iMonteCarloStatisticsFile]);
      mcStatisticsHistogramManager[iMonteCarloStatisticsFile] = new EECHistogramManager(mcStatisticsFile[iMonteCarloStatisticsFile], mcStatisticsCard[iMonteCarloStatisticsFile]);
    }
  }


  // Read the histograms from the defined range from the file
  int iCentralityMatched;
  int iTrackPtMatched;
  int iJetPtMatched;
  double epsilon = 0.0001;
  int lowAnalysisBin, highAnalysisBin;
  std::pair<double,double> shiftedCentralityBin;
  double currentRelativeUncertainty, twoGeVRelativeUncertainty;
  for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        // Read the nominal histograms
        nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt] = nominalHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentrality, iJetPt, iTrackPt, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

        // Normalize nominal histograms to one in the drawing range
        lowAnalysisBin = nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt]->GetXaxis()->FindBin(analysisDeltaR.first + epsilon);
        highAnalysisBin = nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt]->GetXaxis()->FindBin(analysisDeltaR.second - epsilon);
        nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt]->Scale(1.0 / nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt]->Integral(lowAnalysisBin, highAnalysisBin, "width"));

        // Read the jet pT prior histograms
        if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingTruth]){
          iCentralityMatched = jetPtPriorCard->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
          iTrackPtMatched = jetPtPriorCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
          iJetPtMatched = jetPtPriorCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
          jetPtPriorUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt] = jetPtPriorHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

          // Normalize the jet pT prior histograms to one
          jetPtPriorUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt]->Scale(1.0 / jetPtPriorUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
        }

        // Read the background subtraction uncertainty histograms
        if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kBackgroundSubtraction]){
          iCentralityMatched = backgroundSubtractionCard->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
          iTrackPtMatched = backgroundSubtractionCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
          iJetPtMatched = backgroundSubtractionCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
          backgroundSubtractionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt] = backgroundSubtractionHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

          // Normalize the background subtraction histograms to one
          backgroundSubtractionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt]->Scale(1.0 / backgroundSubtractionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
        }

        // Read the relative Monte Carlo non-closure histograms
        if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloNonClosure]){
          shiftedCentralityBin = nominalResultCard->GetBinBordersCentrality(iCentrality);
          iCentralityMatched = monteCarloNonClosureCard->FindBinIndexCentrality(shiftedCentralityBin.first+4, shiftedCentralityBin.second+4);
          iTrackPtMatched = monteCarloNonClosureCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
          iJetPtMatched = monteCarloNonClosureCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloNonClosure] = (TH1D*) monteCarloNonClosureFile->Get(Form("relativeUncertaintyMonteCarloClosure_C%dJ%dT%d", iCentralityMatched, iJetPtMatched, iTrackPtMatched));
        }

        // For case where default results have more mixing than tracking variations: read the relative track selection uncertainty histograms
        if(readRelativeUncertaintyForTracking){

          iCentralityMatched = relativeUncertaintyCard->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
          iTrackPtMatched = relativeUncertaintyCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
          iJetPtMatched = relativeUncertaintyCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));

          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackSelection]){
            energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackSelection] = (TH1D*) relativeUncertaintyFile->Get(Form("systematicUncertainty_trackSelection_C%dJ%dT%d", iCentralityMatched, iJetPtMatched, iTrackPtMatched));
          }

          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSingleTrackEfficiency]){
            energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kSingleTrackEfficiency] = (TH1D*) relativeUncertaintyFile->Get(Form("systematicUncertainty_trackEfficiency_C%dJ%dT%d", iCentralityMatched, iJetPtMatched, iTrackPtMatched));
          }

          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackPairEfficiency]){
            energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackPairEfficiency] = (TH1D*) relativeUncertaintyFile->Get(Form("systematicUncertainty_trackPairEfficiency_C%dJ%dT%d", iCentralityMatched, iJetPtMatched, iTrackPtMatched));
          }

        } else {
        // Regular case where we do the evaluation for the tracking related uncertainties rather than reading relative uncertianties from a premade file

          // Setup the histogram manager for tracking efficiencies
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSingleTrackEfficiency] || !skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackPairEfficiency]){
            iCentralityMatched = trackEfficiencyCard->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = trackEfficiencyCard->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = trackEfficiencyCard->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
          }

          // Read the histograms for single track efficiency
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSingleTrackEfficiency]){
            singleTrackEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][0] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorEfficiencyVariationPlus, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);
            singleTrackEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][1] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorEfficiencyVariationMinus, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);
          }

          // Read the histograms for track pair efficiency
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackPairEfficiency]){
            trackPairEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][0] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorPairEfficiencyVariationPlus, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);
            trackPairEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][1] = trackEfficiencyHistogramManager->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelatorPairEfficiencyVariationMinus, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);
          }

        } // if-else for using premade file for tracking related uncertainties


        for(int iFile = 0; iFile < 2; iFile++){

          if(!readRelativeUncertaintyForTracking){

            // Normalize the single track efficiency histograms to one
            if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSingleTrackEfficiency]){
              singleTrackEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / singleTrackEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
            }

            // Normalize the track pair efficiency histograms to one
            if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackPairEfficiency]){
              trackPairEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / trackPairEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
            }
          } // Regular track uncertainty evaluation

          // Read the jet energy resolution histograms
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyResolution]){
            iCentralityMatched = jetEnergyResolutionCard[iFile]->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = jetEnergyResolutionCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = jetEnergyResolutionCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
            jetEnergyResolutionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = jetEnergyResolutionHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

            // Normalize the jet energy resolution histograms to one
            jetEnergyResolutionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / jetEnergyResolutionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
          }

          // Read the jet energy scale histograms
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyScale]){
            iCentralityMatched = jetEnergyScaleCard[iFile]->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = jetEnergyScaleCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = jetEnergyScaleCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
            jetEnergyScaleUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = jetEnergyScaleHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

            // Normalize the jet energy scale histograms to one
            jetEnergyScaleUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / jetEnergyScaleUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
          }

          // Read the unfolding number of iteration histograms
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingIterations]){
            iCentralityMatched = unfoldingIterationsCard[iFile]->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = unfoldingIterationsCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = unfoldingIterationsCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
            unfoldingIterationsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = unfoldingIterationsHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

            // Normalize the unfolding number of iteration histograms to one
            unfoldingIterationsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / unfoldingIterationsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
          }

          // Read the signal-to-background ratio after unfolding uncertainty histograms
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSignalToBackgroundRatio]){
            iCentralityMatched = signalToBackgroundRatioCard[iFile]->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = signalToBackgroundRatioCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = signalToBackgroundRatioCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
            signalToBackgroundRatioUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = signalToBackgroundRatioHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

            // Normalize the signal-to-background ratio after unfolding histograms to one
            signalToBackgroundRatioUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / signalToBackgroundRatioUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
          }

          // Read the track selection uncertainty histograms
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackSelection] && !readRelativeUncertaintyForTracking){
            iCentralityMatched = trackSelectionCard[iFile]->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = trackSelectionCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = trackSelectionCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
            trackSelectionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = trackSelectionHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

            // Normalize the track selections histograms to one
            trackSelectionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / trackSelectionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
          }

          // Read the centrality shift uncertainty histograms
          if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kCentralityShift]){
            iCentralityMatched = centralityShiftCard[iFile]->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = centralityShiftCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = centralityShiftCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
            centralityShiftUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = centralityShiftHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

            // Normalize the background subtraction histograms to one
            centralityShiftUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / centralityShiftUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
          }

        } // Loop over two file variations

        // Read the Monte Carlo statistics uncertainty histograms
        if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloStatistics]){
          for(int iFile = 0; iFile < nMCStatisticsRandomizations; iFile++){
            iCentralityMatched = mcStatisticsCard[iFile]->FindBinIndexCentrality(nominalResultCard->GetBinBordersCentrality(iCentrality));
            iTrackPtMatched = mcStatisticsCard[iFile]->FindBinIndexTrackPtEEC(nominalResultCard->GetBinBordersTrackPtEEC(iTrackPt));
            iJetPtMatched = mcStatisticsCard[iFile]->FindBinIndexJetPtEEC(nominalResultCard->GetBinBordersJetPtEEC(iJetPt));
            monteCarloStatisticsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile] = mcStatisticsHistogramManager[iFile]->GetHistogramEnergyEnergyCorrelatorProcessed(EECHistogramManager::kEnergyEnergyCorrelator, iCentralityMatched, iJetPtMatched, iTrackPtMatched, EECHistogramManager::kEnergyEnergyCorrelatorUnfoldedSignal);

            // Normalize the Monte Carlo statistics histograms to one
            monteCarloStatisticsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Scale(1.0 / monteCarloStatisticsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt][iFile]->Integral(lowAnalysisBin, highAnalysisBin, "width"));
          } // Loop over different response matrix randomizations
        } // Monte Carlo statistics uncertainty histograms

      } // Track pT loop
    } // Jet pT loop
  } // Centrality loop
  
  // Drawer for illustrative plots
  JDrawer* drawer = new JDrawer();
  drawer->SetDefaultAppearanceSplitCanvas();
  drawer->SetRelativeCanvasSize(1.1,1.1);
  drawer->SetLeftMargin(0.14);
  drawer->SetTopMargin(0.07);
  drawer->SetTitleOffsetY(1.7);
  drawer->SetTitleOffsetX(1.0);
  drawer->SetLogX(true);

  // Legends given to drawns graphs
  TString legendNames[2];

  // Option to ignore some of the differences as unreasonable
  int ignoreIndex = -1;
  
  // ================================================= //
  //   Uncertainty coming from jet energy resolution   //
  // ================================================= //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyResolution]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kJetEnergyResolution] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], jetEnergyResolutionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2);

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kJetEnergyResolution] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "JER varied response down";
            legendNames[1] = "JER varied response up";

            // Set reasonable ratio zoom depending on centrality bin
            if(setAutomaticRatioZoom){
              ratioZoom = std::make_pair(0.9,1.1);
            }

            drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], jetEnergyResolutionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kJetEnergyResolution), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Jet energy resolution uncertainty
  
  // ============================================ //
  //   Uncertainty coming from jet energy scale   //
  // ============================================ //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kJetEnergyScale]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kJetEnergyScale] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], jetEnergyScaleUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2);

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kJetEnergyScale] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "JEC varied response down";
            legendNames[1] = "JEC varied response up";

            // Set reasonable ratio zoom
            if(setAutomaticRatioZoom){
              if(iCentrality == 0 && weightExponent == 2){
                ratioZoom = std::make_pair(0.3,1.7);
              } else if (iCentrality == 1 && weightExponent == 2){
                ratioZoom = std::make_pair(0.6,1.4);
              } else if (iCentrality == 0 && weightExponent == 1){
                ratioZoom = std::make_pair(0.75,1.25);
              } else {
                ratioZoom = std::make_pair(0.8,1.2);
              }
              
            }

            drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], jetEnergyScaleUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kJetEnergyScale), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Jet energy scale uncertainty

  // ==================================================== //
  //   Uncertainty coming from jet pT prior in unfolding  //
  // ==================================================== //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingTruth]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kUnfoldingTruth] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], jetPtPriorUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt]);

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kUnfoldingTruth] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "Weighted prior";

            // Set reasonable ratio zoom
            if(setAutomaticRatioZoom){
              ratioZoom = std::make_pair(0.85,1.15);
            }

            drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], jetPtPriorUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames[0], nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kUnfoldingTruth), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Jet pT prior uncertainty

  // ============================================================= //
  //   Uncertainty coming from number of iterations in unfolding   //
  // ============================================================= //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kUnfoldingIterations]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kUnfoldingIterations] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], unfoldingIterationsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2);

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kUnfoldingIterations] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "Unfolding with 3 iterations";
            legendNames[1] = "Unfolding with 5 iterations";

            // Set reasonable ratio zoom
            if(setAutomaticRatioZoom){
              if(iCentrality == 0){
                ratioZoom = std::make_pair(0.8,1.2);
              } else if (iCentrality == 1){
                ratioZoom = std::make_pair(0.85,1.15);
              } else {
                ratioZoom = std::make_pair(0.9,1.1);
              }

              if(weightExponent == 1){
                ratioZoom = std::make_pair(0.9,1.1);
              }
            }


            drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], unfoldingIterationsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kUnfoldingIterations), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Uncertainty from number of iterations for unfolding
  
  // ================================================== //
  //   Uncertainty coming from background subtraction   //
  // ================================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kBackgroundSubtraction]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kBackgroundSubtraction] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], backgroundSubtractionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt]);

        }

        // Reflected cone cannot be used as a good reference for nominal energy weight and pT < 2 GeV.
        // In the case of the 0-10% centrality bin, comparinf mixed cone results to reflected cone results
        // gives a very large and unrealistic uncertainty. This in this case, we use twice the relative
        // uncertainty in the 2 GeV bin for lower track pT cuts to get a more realistic uncertainty estimate.
        if(weightExponent == 1 && iCentrality == 0){

          // Find the relative uncertainty in the 2 GeV bin
          twoGeVRelativeHistogram = (TH1D*) energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][twoGeVBin][SystematicUncertaintyOrganizer::kBackgroundSubtraction]->Clone(Form("twoGeVRelative%d%d", iCentrality, iJetPt));
          optimusPrimeTheTransformer->TransformToRelativeUncertainty(twoGeVRelativeHistogram, true);

          for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt < twoGeVBin; iTrackPt++){

            // Find the relative uncertainty in the current bin
            currentRelativeHistogram = (TH1D*) energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kBackgroundSubtraction]->Clone(Form("currentRelative%d%d%d", iCentrality, iJetPt, iTrackPt));
            optimusPrimeTheTransformer->TransformToRelativeUncertainty(currentRelativeHistogram, true);

            // Update the current bin uncertainty if it is larger than twice the 2 GeV bin
            for(int iBin = 1; iBin <= currentRelativeHistogram->GetNbinsX(); iBin++){
              twoGeVRelativeUncertainty = twoGeVRelativeHistogram->GetBinError(iBin);
              currentRelativeHistogram->SetBinError(iBin, 2*twoGeVRelativeUncertainty);
            }

            // Transform the relative uncertainties back to absolute ones and set them as the uncertainty in the current bin
            optimusPrimeTheTransformer->TransformToAbsoluteUncertainty(currentRelativeHistogram, energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kBackgroundSubtraction], true);
            energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kBackgroundSubtraction] = currentRelativeHistogram;
          }
        } // Reflected cone limitation for the nominal energy weight

        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kBackgroundSubtraction] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "Reflected cone bg";

            // Set reasonable ratio zoom
            if(setAutomaticRatioZoom){
              if(iCentrality == 0 || (iCentrality == 1 && weightExponent == 2)){
                ratioZoom = std::make_pair(0.8,1.2);
              } else {
                ratioZoom = std::make_pair(0.9,1.1);
              }
            }

            drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], backgroundSubtractionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames[0], nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kBackgroundSubtraction), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);

          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Background subtraction uncertainty

  // ====================================================================== //
  //   Uncertainty coming from signal-to-background ratio after unfolding   //
  // ====================================================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSignalToBackgroundRatio]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kSignalToBackgroundRatio] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], signalToBackgroundRatioUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2);

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kSignalToBackgroundRatio] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "Low estimate for signal-to-bg ratio";
            legendNames[1] = "High estimate for signal-to-bg ratio";

            // Set reasonable ratio zoom
            if(setAutomaticRatioZoom){
              if(iCentrality == 0 && weightExponent == 2){
                ratioZoom = std::make_pair(0.75,1.25);
              } else if(iCentrality == 0 && weightExponent == 1){
                ratioZoom = std::make_pair(0.88,1.12);
              } else {
                ratioZoom = std::make_pair(0.9,1.1);
              }
            }

            drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], signalToBackgroundRatioUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kSignalToBackgroundRatio), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Signal-to-background ratio after unfolding uncertainty

  // =============================================== //
  //     Uncertainty coming from track selection     //
  // =============================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackSelection]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          // Select between previously determined relative uncertainties and new evaluation
          if(readRelativeUncertaintyForTracking){

            optimusPrimeTheTransformer->TransformToRelativeUncertainty(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackSelection], true);
            optimusPrimeTheTransformer->TransformToAbsoluteUncertainty(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackSelection], nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], true);

          } else {

            energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackSelection] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], trackSelectionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2);

            // Draw example plots on how the uncertainty is obtained
            if(plotExample[SystematicUncertaintyOrganizer::kTrackSelection] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
              legendNames[0] = "Loose track selection";
              legendNames[1] = "Tight track selection";

              // Set reasonable ratio zoom
              if(setAutomaticRatioZoom){
                ratioZoom = std::make_pair(0.8,1.2);
              }

              drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], trackSelectionUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kTrackSelection), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
            }
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Track selection uncertainty

  // =================================================== //
  //   Uncertainty coming from single track efficiency   //
  // =================================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kSingleTrackEfficiency]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          // Select between previously determined relative uncertainties and new evaluation
          if(readRelativeUncertaintyForTracking){

            optimusPrimeTheTransformer->TransformToRelativeUncertainty(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kSingleTrackEfficiency], true);
            optimusPrimeTheTransformer->TransformToAbsoluteUncertainty(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kSingleTrackEfficiency], nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], true);

          } else {

            energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kSingleTrackEfficiency] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], singleTrackEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2);

            // Draw example plots on how the uncertainty is obtained
            if(plotExample[SystematicUncertaintyOrganizer::kSingleTrackEfficiency] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
              legendNames[0] = "Efficiency - 5%";
              legendNames[1] = "Efficiency + 5%";

              // Set reasonable ratio zoom
              if(setAutomaticRatioZoom){
                ratioZoom = std::make_pair(0.999999,1.000001);
              }

              drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], singleTrackEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kSingleTrackEfficiency), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
            }
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Single track efficiency uncertainty

  // =================================================== //
  //    Uncertainty coming from track pair efficiency    //
  // =================================================== //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kTrackPairEfficiency]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          // Select between previously determined relative uncertainties and new evaluation
          if(readRelativeUncertaintyForTracking){

            optimusPrimeTheTransformer->TransformToRelativeUncertainty(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackPairEfficiency], true);
            optimusPrimeTheTransformer->TransformToAbsoluteUncertainty(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackPairEfficiency], nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], true);

          } else {

            energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kTrackPairEfficiency] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], trackPairEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2);

            // Draw example plots on how the uncertainty is obtained
            if(plotExample[SystematicUncertaintyOrganizer::kTrackPairEfficiency] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
              legendNames[0] = "Pair efficiency - 10%";
              legendNames[1] = "Pair efficiency + 10%";

              // Set reasonable ratio zoom
              if(setAutomaticRatioZoom){
                ratioZoom = std::make_pair(0.8,1.2);
              }

              drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], trackPairEfficiencyUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kTrackPairEfficiency), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
            }
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Track pair efficiency uncertainty

  // ================================================ //
  //     Uncertainty coming from centrality shift     //
  // ================================================ //
  
  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kCentralityShift]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          if(weightExponent == 1 && iCentrality == 3 && iTrackPt == 1 && iJetPt == 5){
            ignoreIndex = 0;
          } else {
            ignoreIndex = -1;
          }

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kCentralityShift] = findTheDifference(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], centralityShiftUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, ignoreIndex);

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kCentralityShift] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "Unfolding with 2% shift";
            legendNames[1] = "Unfolding with 6% shift";

            // Set reasonable ratio zoom
            if(setAutomaticRatioZoom){
              if(iCentrality == 0){
                ratioZoom = std::make_pair(0.85,1.15);
              } else {
                ratioZoom = std::make_pair(0.9,1.1);
              }
            }

            drawIllustratingPlots(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], centralityShiftUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], 2, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames, nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kCentralityShift), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Centrality shift uncertainty

  // ======================================================================= //
  //   Uncertainty coming from limited statistics in the Monte Carlo sample  //
  // ======================================================================= //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloStatistics]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloStatistics] = findStandardDeviation(nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], monteCarloStatisticsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], nMCStatisticsRandomizations);

          // Draw example plots on how the uncertainty is obtained
          if(plotExample[SystematicUncertaintyOrganizer::kMonteCarloStatistics] && std::binary_search(drawnCentralityBins.begin(), drawnCentralityBins.end(), iCentrality) && std::binary_search(drawnJetPtBins.begin(), drawnJetPtBins.end(), iJetPt) && std::binary_search(drawnTrackPtBins.begin(), drawnTrackPtBins.end(), iTrackPt)){
            legendNames[0] = "Response matrix variations";

            // Set reasonable ratio zoom
            if(setAutomaticRatioZoom){
              ratioZoom = std::make_pair(0.9,1.1);
              if(weightExponent == 2){
                ratioZoom = std::make_pair(0.85,1.15);
              }
            }

            drawIllustratingPlotsMonochrome(drawer, nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], monteCarloStatisticsUncertaintyCorrelators[iCentrality][iJetPt][iTrackPt], nMCStatisticsRandomizations, iCentrality, iJetPt, iTrackPt, nominalResultCard, legendNames[0], nameGiver->GetSystematicUncertaintyName(SystematicUncertaintyOrganizer::kMonteCarloStatistics), nameAdder[weightExponent-1], analysisDeltaR, ratioZoom);
          }
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Uncertainty from limited statistics in Monte Carlo

  // ===================================================== //
  //   Uncertainty coming from non-closure in Monte Carlo  //
  // ===================================================== //

  if(!skipUncertaintySource[SystematicUncertaintyOrganizer::kMonteCarloNonClosure]){
    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

          optimusPrimeTheTransformer->SuppressSingleBinFluctuations(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloNonClosure], analysisDeltaR.first, analysisDeltaR.second, 3, 0.5);
          optimusPrimeTheTransformer->TransformToAbsoluteUncertainty(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kMonteCarloNonClosure], nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt], false);

          // Note: Illustrating plots for this uncertainty can be plotter with fullAnalysisClosure.C macro
      
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop
  } // Monte Carlo non-closure uncertainty
  
  // ============================================= //
  //   Add all uncertainty sources in quadrature   //
  // ============================================= //
  
  double sumOfSquares;
  for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
    for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
      for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){

        // Clone the uncertainty histogram from the nominal one
        energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kAll] = (TH1D*) nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt]->Clone(Form("summedUncertainty%d%d%d", iCentrality, iJetPt, iTrackPt));
      
        // Calculate a sum of squared from all evaluated uncertainties
        for(int iBin = 1; iBin <= nominalEnergyEnergyCorrelators[iCentrality][iJetPt][iTrackPt]->GetNbinsX(); iBin++){
          sumOfSquares = 0;
          for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::kAll; iUncertainty++){
            if(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][iUncertainty] != NULL){
              sumOfSquares = sumOfSquares + TMath::Power(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][iUncertainty]->GetBinError(iBin),2);
            }
          } // Uncertainty type loop
          energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][SystematicUncertaintyOrganizer::kAll]->SetBinError(iBin, TMath::Sqrt(sumOfSquares));
        } // Bin loop
      } // Track pT loop
    } // Jet pT loop
  } // Centrality loop
  
  // =========================================================== //
  //   Write the systematic uncertainty histograms into a file   //
  // =========================================================== //
  
  // If an output file name is given, put the total uncertainties to an output file
  if(outputFileName.EndsWith(".root")){
    TFile* outputFile = new TFile(outputFileName,"UPDATE");
    TString saveName;

    for(int iCentrality = firstStudiedCentralityBin; iCentrality <= lastStudiedCentralityBin; iCentrality++){
      for(int iJetPt = firstStudiedJetPtBinEEC; iJetPt <= lastStudiedJetPtBinEEC; iJetPt++){
        for(int iTrackPt = firstStudiedTrackPtBinEEC; iTrackPt <= lastStudiedTrackPtBinEEC; iTrackPt++){
          for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
            if(energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][iUncertainty] != NULL){
              saveName = Form("systematicUncertainty_%s_C%dJ%dT%d", nameGiver->GetSystematicUncertaintyName(iUncertainty).Data(), iCentrality, iJetPt, iTrackPt);
              energyEnergyCorrelatorSystematicUncertainties[iCentrality][iJetPt][iTrackPt][iUncertainty]->Write(saveName);
            }
          } // Uncertainty loop
        } // Track pT loop
      } // Jet pT loop
    } // Centrality loop

    // Write the card from the nominal file, since all indices are syncronized with that
    nominalResultCard->Write(outputFile);

    // Close the output file
    outputFile->Close();

  }
  
  // =========================================================================== //
  // Print slides summarizing all the different sources of systemtic uncertainty //
  // =========================================================================== //
  
  // if(printUncertainties){
    
  //   // Print a slide with uncertainties for each source and each centrality for each V
  //   char namer[100];
  //   for(int iFlow = firstFlow-1; iFlow <= lastFlow-1; iFlow++){
      
  //     sprintf(namer,"\\frametitle{Uncertainty for jet $v_{%d}$}", iFlow+1);
      
  //     cout << endl;
  //     cout << "\\begin{frame}" << endl;
  //     cout << namer << endl;
  //     cout << "\\begin{center}" << endl;
  //     cout << "  \\begin{tabular}{cccccc}" << endl;
  //     cout << "    \\toprule" << endl;
  //     cout << "    Source & C: 0-10 & C: 10-30 & C: 30-50 \\\\" << endl;
  //     cout << "    \\midrule" << endl;
      
  //     // Set the correct precision for printing floating point numbers
  //     cout << fixed << setprecision(4);
      
  //     // First, print the actual values of vn:s
  //     cout << "$v_{" << iFlow+1 << "}$ ";
      
  //     for(int iCentrality = 0; iCentrality < nCentralityBins; iCentrality++){
  //       nominalResultGraph[iFlow]->GetPoint(iCentrality, nominalX, nominalY);
  //       cout << " & $" << nominalY << "$";
  //     }
  //     cout << " \\\\" << endl;
  //     cout << "    \\midrule" << endl;
      
  //     // Print the relative uncertainties
      
  //     for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
  //       cout << uncertaintyNamer->GetLongRangeUncertaintyName(iUncertainty).Data();
  //       for(int iCentrality = 0; iCentrality < nCentralityBins; iCentrality++){
  //         cout << " & $" << relativeUncertaintyTable[iUncertainty][iFlow][iCentrality] << "$";
  //       }
  //       cout << " \\\\" << endl;
  //     }
      
  //     cout << "    \\midrule" << endl;
      
  //     // Print the absolute uncertainties
      
  //     for(int iUncertainty = 0; iUncertainty < SystematicUncertaintyOrganizer::knUncertaintySources; iUncertainty++){
  //       cout << uncertaintyNamer->GetLongRangeUncertaintyName(iUncertainty).Data();
  //       for(int iCentrality = 0; iCentrality < nCentralityBins; iCentrality++){
  //         cout << " & $" << absoluteUncertaintyTable[iUncertainty][iFlow][iCentrality] << "$";
  //       }
  //       cout << " \\\\" << endl;
  //     }
      
      
  //     cout << "    \\bottomrule" << endl;
  //     cout << "  \\end{tabular}" << endl;
  //     cout << "\\end{center}" << endl;
  //     cout << "\\begin{itemize}" << endl;
  //     cout << "  \\item Top: value. Middle: relative uncertainty. Bottom: absolute uncertainty." << endl;
  //     cout << "\\end{itemize}" << endl;
  //     cout << "\\end{frame}" << endl;
  //     cout << endl;
      
  //   } // vn loop
    
  // } // Printing uncertainties
}

/*
 * Function for finding the relative and absolute difference of points in two graphs
 *
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histograms containing varied results for systematic uncertainty estimation
 *  const int nVariations = Number of variations used to estimate the systematic uncertainties
 *  const int ignoreIndex = If some of the variations is deemed bad, ignore that in the error calculation
 *
 *  return: Histogram where the error bars in each point correspond to estimated systematic uncertainty
 *
 */
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int ignoreIndex){
  
  // Create an uncertainty histogram from the nominal results
  TH1D* uncertaintyHistogram = (TH1D*) nominalResult->Clone(Form("uncertaintyFor%s", variedResult[0]->GetName()));
  
  // Loop over the bins in the histogram, and in each bin assign the greates variation from the nominal result as uncertainty
  double biggestDifference, currentDifference;
  for(int iBin = 1; iBin <= nominalResult->GetNbinsX(); iBin++){
    biggestDifference = 0;
    for(int iVariation = 0; iVariation < nVariations; iVariation++){
      if(iVariation == ignoreIndex) continue;
      currentDifference = TMath::Abs(nominalResult->GetBinContent(iBin) - variedResult[iVariation]->GetBinContent(iBin));
      if(currentDifference > biggestDifference) biggestDifference = currentDifference;
    }
    uncertaintyHistogram->SetBinError(iBin, biggestDifference);
  } // Histogram bin loop
  
  // Return the histogram where the errors represent the systematic uncertainties
  return uncertaintyHistogram;
  
}

/*
 * Function for finding the relative and absolute difference of points in two graphs
 *
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histogram containing varied results for systematic uncertainty estimation
 *  const int nVariations = Number of variations used to estimate the systematic uncertainties
 *
 *  return: Histogram where the error bars in each point correspond to estimated systematic uncertainty
 *
 */
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult[], const int nVariations){
  
  return findTheDifference(nominalResult, variedResult, nVariations, -1);
  
}

/*
 * Function for finding the relative and absolute difference of points in two graphs
 *
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histogram containing varied results for systematic uncertainty estimation
 *
 *  return: Histogram where the error bars in each point correspond to estimated systematic uncertainty
 *
 */
TH1D* findTheDifference(TH1D* nominalResult, TH1D* variedResult){
  
  // Enclose the single graph to an array and use the difference finder for graph array
  TH1D* comparisonArray[1] = {variedResult};
  return findTheDifference(nominalResult, comparisonArray, 1, -1);
  
}

/*
 * Function for finding standard deviation from a set of varied results
 *
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histograms containing varied results for systematic uncertainty estimation
 *  const int nVariations = Number of variations used to estimate the systematic uncertainties
 *
 *  return: Histogram where the error bars in each point correspond to estimated systematic uncertainty
 *
 */
TH1D* findStandardDeviation(TH1D* nominalResult, TH1D* variedResult[], const int nVariations){
  
  // Create an uncertainty histogram from the nominal results
  TH1D* uncertaintyHistogram = (TH1D*) nominalResult->Clone(Form("uncertaintyFor%s", variedResult[0]->GetName()));
  
  // In each bin, assign the systematic uncertainty to be the standard deviation of varied results
  double meanValue;
  double standardDeviation;
  for(int iBin = 1; iBin <= nominalResult->GetNbinsX(); iBin++){

    // First, calculate the mean value of the varied results.
    meanValue = 0;
    for(int iVariation = 0; iVariation < nVariations; iVariation++){
      meanValue += variedResult[iVariation]->GetBinContent(iBin);
    }
    meanValue /= nVariations;

    // After we have the mean value, we can calculate stadard deviation
    standardDeviation = 0;
    for(int iVariation = 0; iVariation < nVariations; iVariation++){
      standardDeviation += TMath::Power(variedResult[iVariation]->GetBinContent(iBin) - meanValue, 2);
    }
    standardDeviation = TMath::Sqrt(standardDeviation / nVariations);

    uncertaintyHistogram->SetBinError(iBin, standardDeviation);
  } // Histogram bin loop
  
  // Return the histogram where the errors represent the systematic uncertainties
  return uncertaintyHistogram;
  
}

/*
 * Draw plots illustrating how systematic uncertainties are estimated form a certain source
 *
 *  JDrawer* drawer = JDrawer doing the dirty work in drawing
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult[] = Array of histograms containing variation of results around the nominal one
 *  const int nVariations = Number of variations around the nominal result
 *  const int iCentrality = Centrality index of the considered bin
 *  const int iJetPt = Jet pT index of the considered bin
 *  const int iTrackPt = Track pT index of the considered bin
 *  EECCard* card = Card used to interpret the bin index
 *  TString comparisonLegend[] = An array of strings describing each result variation
 *  TString plotName = String added to saved plots. If left empty, the plots are not saved into files.
 *  TString plotComment = Comment given to the saved plots
 *  std::pair<double, double> drawingRange = Drawing range for x-axis
 *  std::pair<double, double> ratioZoom = Y-axis zoom for the ratio
 */
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iCentrality, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend[], TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom){
  
  const int markers[] = {kFullDiamond, kFullDoubleDiamond, kFullCross, kFullFourTrianglesPlus, kFullSquare, kFullStar};
  const int colors[] = {kBlue, kRed, kGreen+3, kMagenta, kCyan, kViolet, kBlack};
  
  // Interpret the given binning information
  TString centralityString = Form("Cent: %.0f-%.0f%%", card->GetLowBinBorderCentrality(iCentrality), card->GetHighBinBorderCentrality(iCentrality));
  TString compactCentralityString = Form("_C=%.0f-%.0f", card->GetLowBinBorderCentrality(iCentrality), card->GetHighBinBorderCentrality(iCentrality));
  TString jetPtString = Form("%.0f < jet p_{T} < %.0f", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString compactJetPtString = Form("_J=%.0f-%.0f", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString trackPtString = Form("%.1f < track p_{T}",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  TString compactTrackPtString = Form("_T>%.1f",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  compactTrackPtString.ReplaceAll(".","v");

  // Calculate ratios between nominal and comparison graphs
  TH1D *ratioHistogram[nVariations];
  for(int iVariation = 0; iVariation < nVariations; iVariation++){
    ratioHistogram[iVariation] = (TH1D*) variedResult[iVariation]->Clone(Form("ratio_%s", comparisonLegend[iVariation].Data()));
    ratioHistogram[iVariation]->Divide(nominalResult);
  } // Varied results loop

  // Create a new canvas for the plot
  drawer->CreateSplitCanvas();

  // Use logarithmic axis for EEC
  drawer->SetLogY(true);

  // Check from plot comment if we need to also add another line to the legend
  bool hasHigherWeightExponent = (plotComment == "_energyWeightSquared");

  // Setup the legend for plots
  TLegend *legend = new TLegend(0.23,0.23-nVariations*0.06-hasHigherWeightExponent*0.06,0.46,0.6);
  legend->SetFillStyle(0);legend->SetBorderSize(0);legend->SetTextSize(0.05);legend->SetTextFont(62);
  legend->AddEntry((TObject*) 0, Form("%s 5.02 TeV",card->GetAlternativeDataType().Data()), "");
  if(hasHigherWeightExponent) legend->AddEntry((TObject*) 0, "Energy weight squared","");
  legend->AddEntry((TObject*) 0, centralityString.Data(),"");
  legend->AddEntry((TObject*) 0, jetPtString.Data(),"");
  legend->AddEntry((TObject*) 0, trackPtString.Data(),"");

  // Set the x-axis drawing range
  nominalResult->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  // Draw the nominal result to the upper canvas
  nominalResult->SetLineColor(kBlack);
  drawer->DrawHistogramToUpperPad(nominalResult, "#Deltar", "EEC Signal", " ");
  legend->AddEntry(nominalResult, "Nominal", "l");

  // Draw the variations to the same plot
  for(int iVariation = 0; iVariation < nVariations; iVariation++) {
    variedResult[iVariation]->SetLineColor(colors[iVariation]);
    variedResult[iVariation]->Draw("same");
    legend->AddEntry(variedResult[iVariation], comparisonLegend[iVariation], "l");
  }

  // Draw the legends to the upper pad
  legend->Draw();

  // Linear scale for the ratio
  drawer->SetLogY(false);

  // Set the x-axis drawing range
  ratioHistogram[0]->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  ratioHistogram[0]->SetLineColor(colors[0]);
  ratioHistogram[0]->GetYaxis()->SetRangeUser(ratioZoom.first, ratioZoom.second);
  drawer->SetGridY(true);
  drawer->DrawHistogramToLowerPad(ratioHistogram[0], "#Deltar", "#frac{Variation}{Nominal}", " ");
  for(int iVariation = 1; iVariation < nVariations; iVariation++) {
    ratioHistogram[iVariation]->SetLineColor(colors[iVariation]);
    ratioHistogram[iVariation]->Draw("same");
  }
  drawer->SetGridY(false);
  
  // If a plot name is given, save the plot in a file
  if(plotName != ""){
    gPad->GetCanvas()->SaveAs(Form("figures/systematicUncertainty_%s_PbPb%s%s%s%s.pdf", plotName.Data(), plotComment.Data(), compactCentralityString.Data(), compactJetPtString.Data(), compactTrackPtString.Data()));
  }
}

/*
 * Draw plots illustrating how systematic uncertainties are estimated form a certain source
 *
 *  JDrawer* drawer = JDrawer doing the dirty work in drawing
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult = Histogram containing variation of results around the nominal one
 *  const int iCentrality = Centrality index of the considered bin
 *  const int iJetPt = Jet pT index of the considered bin
 *  const int iTrackPt = Track pT index of the considered bin
 *  EECCard* card = Card used to interpret the binning information
 *  TString comparisonLegend = String describing the variation
 *  TString plotName = String added to saved plots. If left empty, the plots are not saved into files.
 *  TString plotComment = Comment given to the saved plots
 *  std::pair<double, double> drawingRange = Drawing range for x-axis
 *  std::pair<double, double> ratioZoom = Y-axis zoom for the ratio
 */
void drawIllustratingPlots(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult, const int iCentrality, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom){
  TH1D* variedResultArray[1] = {variedResult};
  TString comparisonLegendArray[1] = {comparisonLegend};
  drawIllustratingPlots(drawer, nominalResult, variedResultArray, 1, iCentrality, iJetPt, iTrackPt, card, comparisonLegendArray, plotName, plotComment, drawingRange, ratioZoom);
}

/*
 * Draw plots illustrating how systematic uncertainties are estimated form a certain source
 *
 *  JDrawer* drawer = JDrawer doing the dirty work in drawing
 *  TH1D* nominalResult = Histogram containing nominal results
 *  TH1D* variedResult[] = Array of histograms containing variation of results around the nominal one
 *  const int nVariations = Number of variations around the nominal result
 *  const int iCentrality = Centrality index of the considered bin
 *  const int iJetPt = Jet pT index of the considered bin
 *  const int iTrackPt = Track pT index of the considered bin
 *  EECCard* card = Card used to interpret the bin index
 *  TString comparisonLegend = An array of strings describing each result variation
 *  TString plotName = String added to saved plots. If left empty, the plots are not saved into files.
 *  TString plotComment = Comment given to the saved plots
 *  std::pair<double, double> drawingRange = Drawing range for x-axis
 *  std::pair<double, double> ratioZoom = Y-axis zoom for the ratio
 */
void drawIllustratingPlotsMonochrome(JDrawer* drawer, TH1D* nominalResult, TH1D* variedResult[], const int nVariations, const int iCentrality, const int iJetPt, const int iTrackPt, EECCard* card, TString comparisonLegend, TString plotName, TString plotComment, std::pair<double, double> drawingRange, std::pair<double, double> ratioZoom){
  
  // Interpret the given binning information
  TString centralityString = Form("Cent: %.0f-%.0f%%", card->GetLowBinBorderCentrality(iCentrality), card->GetHighBinBorderCentrality(iCentrality));
  TString compactCentralityString = Form("_C=%.0f-%.0f", card->GetLowBinBorderCentrality(iCentrality), card->GetHighBinBorderCentrality(iCentrality));
  TString jetPtString = Form("%.0f < jet p_{T} < %.0f GeV", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString compactJetPtString = Form("_J=%.0f-%.0f", card->GetLowBinBorderJetPtEEC(iJetPt), card->GetHighBinBorderJetPtEEC(iJetPt));
  TString trackPtString = Form("p_{T}^{ch} > %.1f GeV",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  TString compactTrackPtString = Form("_T>%.1f",card->GetLowBinBorderTrackPtEEC(iTrackPt));
  compactTrackPtString.ReplaceAll(".","v");

  // Calculate ratios between nominal and comparison graphs
  TH1D *ratioHistogram[nVariations];
  for(int iVariation = 0; iVariation < nVariations; iVariation++){
    ratioHistogram[iVariation] = (TH1D*) variedResult[iVariation]->Clone(Form("ratio%d_%s", iVariation, comparisonLegend.Data()));
    ratioHistogram[iVariation]->Divide(nominalResult);
  } // Varied results loop

  // Create a new canvas for the plot
  drawer->CreateSplitCanvas();

  // Use logarithmic axis for EEC
  drawer->SetLogY(true);

  // Check from plot comment if we need to also add another line to the legend
  int weightExponent = (plotComment == "_energyWeightSquared") + 1;

  // Setup the legend for plots
  TLegend *legend = new TLegend(0.23,0.08,0.46,0.6);
  legend->SetFillStyle(0);legend->SetBorderSize(0);legend->SetTextSize(0.05);legend->SetTextFont(62);
  legend->AddEntry((TObject*) 0, Form("%s 5.02 TeV",card->GetAlternativeDataType().Data()), "");
  legend->AddEntry((TObject*) 0, Form("n = %d", weightExponent),"");
  legend->AddEntry((TObject*) 0, centralityString.Data(),"");
  legend->AddEntry((TObject*) 0, jetPtString.Data(),"");
  legend->AddEntry((TObject*) 0, trackPtString.Data(),"");

  // Set the x-axis drawing range
  nominalResult->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  // Draw the nominal result to the upper canvas
  nominalResult->SetLineColor(kBlack);
  drawer->DrawHistogramToUpperPad(nominalResult, "#Deltar", "EEC Signal", " ");
  legend->AddEntry(nominalResult, "Nominal", "l");

  // Draw the variations to the same plot
  for(int iVariation = 0; iVariation < nVariations; iVariation++) {
    variedResult[iVariation]->SetLineColor(kBlue);
    variedResult[iVariation]->Draw("same");
  }
  legend->AddEntry(variedResult[0], comparisonLegend, "l");

  // Draw the legends to the upper pad
  legend->Draw();

  // Linear scale for the ratio
  drawer->SetLogY(false);

  // Set the x-axis drawing range
  ratioHistogram[0]->GetXaxis()->SetRangeUser(drawingRange.first, drawingRange.second);

  ratioHistogram[0]->SetLineColor(kBlue);
  ratioHistogram[0]->GetYaxis()->SetRangeUser(ratioZoom.first, ratioZoom.second);
  drawer->SetGridY(true);
  drawer->DrawHistogramToLowerPad(ratioHistogram[0], "#Deltar", "#frac{Variation}{Nominal}", " ");
  for(int iVariation = 1; iVariation < nVariations; iVariation++) {
    ratioHistogram[iVariation]->SetLineColor(kBlue);
    ratioHistogram[iVariation]->Draw("same");
  }
  drawer->SetGridY(false);
  
  // If a plot name is given, save the plot in a file
  if(plotName != ""){
    gPad->GetCanvas()->SaveAs(Form("figures/systematicUncertainty_%s_PbPb%s%s%s%s.pdf", plotName.Data(), plotComment.Data(), compactCentralityString.Data(), compactJetPtString.Data(), compactTrackPtString.Data()));
  }
}

